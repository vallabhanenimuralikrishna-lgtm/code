from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from analysis.sentiment import AggregateSentiment, Signal as SentSignal
from analysis.technical import TechnicalResult, TechSignal
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class Action(Enum):
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"
    EXIT = "EXIT"


@dataclass
class TradeDecision:
    action: Action
    confidence: float
    reason: str


class SignalCombiner:
    def __init__(self):
        self._last_exit_time = None
        self._cooldown_seconds = 300  # 5 min re-entry cooldown

    def combine(self, sentiment: AggregateSentiment, technical: TechnicalResult,
                has_position: bool, position_direction: str = None) -> TradeDecision:

        # Check re-entry cooldown
        if self._last_exit_time and not has_position:
            elapsed = (datetime.now() - self._last_exit_time).total_seconds()
            if elapsed < self._cooldown_seconds:
                return TradeDecision(
                    action=Action.HOLD,
                    confidence=0,
                    reason=f"Cooldown: {int(self._cooldown_seconds - elapsed)}s remaining",
                )

        sent_bullish = sentiment.overall_signal == SentSignal.BULLISH
        sent_bearish = sentiment.overall_signal == SentSignal.BEARISH
        tech_bullish = technical.signal == TechSignal.BULLISH
        tech_bearish = technical.signal == TechSignal.BEARISH

        confidence = min(sentiment.confidence, 1.0) * 0.5 + (1.0 if technical.signal != TechSignal.NEUTRAL else 0.0) * 0.5

        # If we have a position, check for exit signals
        if has_position:
            if position_direction == "LONG" and (sent_bearish or tech_bearish):
                self._last_exit_time = datetime.now()
                return TradeDecision(
                    action=Action.EXIT,
                    confidence=confidence,
                    reason=f"Exit LONG: sentiment={sentiment.overall_signal.value}, tech={technical.signal.value}",
                )
            if position_direction == "SHORT" and (sent_bullish or tech_bullish):
                self._last_exit_time = datetime.now()
                return TradeDecision(
                    action=Action.EXIT,
                    confidence=confidence,
                    reason=f"Exit SHORT: sentiment={sentiment.overall_signal.value}, tech={technical.signal.value}",
                )
            return TradeDecision(
                action=Action.HOLD,
                confidence=confidence,
                reason=f"Hold {position_direction}: sentiment={sentiment.overall_signal.value}, tech={technical.signal.value}",
            )

        # No position - check for entry
        if sent_bullish and tech_bullish:
            if sentiment.confidence >= settings.SENTIMENT_MIN_CONFIDENCE:
                return TradeDecision(
                    action=Action.BUY,
                    confidence=confidence,
                    reason=f"BUY: sentiment={sentiment.weighted_score:.2f} ({sentiment.item_count} items), tech={technical.reason}",
                )

        if sent_bearish and tech_bearish:
            if sentiment.confidence >= settings.SENTIMENT_MIN_CONFIDENCE:
                return TradeDecision(
                    action=Action.SELL,
                    confidence=confidence,
                    reason=f"SELL: sentiment={sentiment.weighted_score:.2f} ({sentiment.item_count} items), tech={technical.reason}",
                )

        return TradeDecision(
            action=Action.HOLD,
            confidence=0,
            reason=f"No signal: sentiment={sentiment.overall_signal.value}, tech={technical.signal.value}",
        )
