"""
Selects the best instrument to trade from Nifty index + Nifty 50 stock futures.

Selection criteria:
1. Must have a clear sentiment signal (news-driven)
2. Must have technical confirmation (EMA crossover)
3. Ranked by signal strength (sentiment confidence x news volume)
4. Must be affordable within capital constraints (margin check)
"""

from dataclasses import dataclass
from typing import Optional, List
from analysis.news_matcher import NewsMatcher
from analysis.sentiment import FinancialSentimentAnalyzer, Signal
from analysis.technical import TechnicalAnalyzer, TechSignal
from data.market_data import (
    MultiInstrumentData, get_current_futures_symbol, get_stock_futures_symbol
)
from config import settings
from config.instruments import NIFTY50_STOCKS
from utils.logger import get_logger

logger = get_logger(__name__)

# Approximate MIS margin as % of contract value (conservative estimate)
# Actual margins vary; Zerodha provides margin calculator API
MIS_MARGIN_PCT = 0.10  # ~10% for most stock futures MIS


@dataclass
class InstrumentCandidate:
    symbol: str  # e.g., "RELIANCE" or "NIFTY"
    trading_symbol: str  # e.g., "RELIANCE26APRFUT"
    direction: str  # "LONG" or "SHORT"
    lot_size: int
    ltp: float
    margin_required: float
    sentiment_signal: Signal
    sentiment_score: float
    tech_signal: TechSignal
    signal_strength: float
    direct_news_count: int
    reason: str


class InstrumentSelector:
    def __init__(self, kite, multi_data: MultiInstrumentData):
        self.kite = kite
        self.multi_data = multi_data
        self.news_matcher = NewsMatcher()
        self.sentiment_analyzer = FinancialSentimentAnalyzer()

    def select_best(self, news_items: list, capital: float = None) -> Optional[InstrumentCandidate]:
        """
        Scan all instruments and return the best trading opportunity.
        Returns None if no good opportunity found.
        """
        capital = capital or settings.CAPITAL

        # If stock futures disabled, only check Nifty
        if not settings.ENABLE_STOCK_FUTURES:
            return self._check_nifty_only(news_items, capital)

        # Step 1: Get stock-level sentiments from news
        stock_sentiments = self.news_matcher.get_stock_sentiments(
            news_items, self.sentiment_analyzer
        )

        if not stock_sentiments:
            logger.debug("No stock-specific sentiment signals found")
            return self._check_nifty_only(news_items, capital)

        # Step 2: Check technical confirmation for top sentiment stocks
        candidates = []

        # Sort by signal strength, check top 5 to limit API calls
        sorted_stocks = sorted(
            stock_sentiments.items(),
            key=lambda x: x[1]["signal_strength"],
            reverse=True,
        )[:5]

        for symbol, sent_data in sorted_stocks:
            sentiment = sent_data["sentiment"]
            fut_symbol = get_stock_futures_symbol(self.kite, symbol)
            if not fut_symbol:
                continue

            # Check if instrument exists
            token = self.multi_data.get_instrument_token(fut_symbol)
            if not token:
                logger.debug(f"No futures found for {symbol} ({fut_symbol})")
                continue

            # Get technical signal
            candles = self.multi_data.get_candles(fut_symbol)
            if candles.empty or len(candles) < settings.EMA_SLOW + 5:
                continue

            tech_analyzer = TechnicalAnalyzer.__new__(TechnicalAnalyzer)
            tech_result = self._compute_technical(candles)

            # Check if sentiment and technical agree
            if not self._signals_agree(sentiment.overall_signal, tech_result.signal):
                logger.debug(
                    f"{symbol}: signals disagree "
                    f"(sent={sentiment.overall_signal.value}, tech={tech_result.signal.value})"
                )
                continue

            # Check margin affordability
            lot_size = self.multi_data.get_lot_size(symbol)
            ltp = self.multi_data.get_ltp(fut_symbol)
            if ltp <= 0:
                continue

            margin_required = ltp * lot_size * MIS_MARGIN_PCT
            if margin_required > capital * 0.9:  # Keep 10% buffer
                logger.debug(f"{symbol}: margin Rs {margin_required:.0f} exceeds capital")
                continue

            direction = "LONG" if sentiment.overall_signal == Signal.BULLISH else "SHORT"

            candidates.append(InstrumentCandidate(
                symbol=symbol,
                trading_symbol=fut_symbol,
                direction=direction,
                lot_size=lot_size,
                ltp=ltp,
                margin_required=margin_required,
                sentiment_signal=sentiment.overall_signal,
                sentiment_score=sentiment.weighted_score,
                tech_signal=tech_result.signal,
                signal_strength=sent_data["signal_strength"],
                direct_news_count=sent_data["direct_news_count"],
                reason=(
                    f"{symbol}: {direction} | "
                    f"sentiment={sentiment.weighted_score:.2f} "
                    f"({sent_data['direct_news_count']} direct news) | "
                    f"tech={tech_result.reason}"
                ),
            ))

        # Also check Nifty itself
        nifty_candidate = self._check_nifty_only(news_items, capital)
        if nifty_candidate:
            candidates.append(nifty_candidate)

        if not candidates:
            return None

        # Pick the best: highest signal strength
        best = max(candidates, key=lambda c: c.signal_strength)
        logger.info(f"Selected instrument: {best.reason}")
        return best

    def _check_nifty_only(self, news_items: list, capital: float) -> Optional[InstrumentCandidate]:
        """Check Nifty index futures as a candidate."""
        # Aggregate all news for general market sentiment
        sentiment = self.sentiment_analyzer.analyze_batch(news_items)
        if sentiment.overall_signal == Signal.NEUTRAL:
            return None

        nifty_symbol = get_current_futures_symbol(self.kite)
        candles = self.multi_data.get_candles(nifty_symbol)
        if candles.empty or len(candles) < settings.EMA_SLOW + 5:
            return None

        tech_result = self._compute_technical(candles)

        if not self._signals_agree(sentiment.overall_signal, tech_result.signal):
            return None

        lot_size = settings.LOT_SIZE
        ltp = self.multi_data.get_ltp(nifty_symbol)
        if ltp <= 0:
            return None

        margin_required = ltp * lot_size * MIS_MARGIN_PCT
        if margin_required > capital * 0.9:
            return None

        direction = "LONG" if sentiment.overall_signal == Signal.BULLISH else "SHORT"
        # Nifty gets a base signal strength (lower than direct stock news)
        strength = abs(sentiment.weighted_score) * sentiment.confidence * 0.8

        return InstrumentCandidate(
            symbol="NIFTY",
            trading_symbol=nifty_symbol,
            direction=direction,
            lot_size=lot_size,
            ltp=ltp,
            margin_required=margin_required,
            sentiment_signal=sentiment.overall_signal,
            sentiment_score=sentiment.weighted_score,
            tech_signal=tech_result.signal,
            signal_strength=strength,
            direct_news_count=sentiment.item_count,
            reason=(
                f"NIFTY: {direction} | "
                f"market sentiment={sentiment.weighted_score:.2f} "
                f"({sentiment.item_count} items) | "
                f"tech={tech_result.reason}"
            ),
        )

    def _compute_technical(self, candles):
        """Compute technical signal from candle DataFrame directly."""
        import pandas as pd
        import numpy as np
        from analysis.technical import TechnicalResult, TechSignal, VOLUME_CONFIRMATION_RATIO

        df = candles.copy()
        df["ema_fast"] = df["close"].ewm(span=settings.EMA_FAST, adjust=False).mean()
        df["ema_slow"] = df["close"].ewm(span=settings.EMA_SLOW, adjust=False).mean()

        # RSI
        delta = df["close"].diff()
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.ewm(span=settings.RSI_PERIOD, adjust=False).mean()
        avg_loss = loss.ewm(span=settings.RSI_PERIOD, adjust=False).mean()
        rs = avg_gain / avg_loss.replace(0, np.nan)
        df["rsi"] = (100 - (100 / (1 + rs))).fillna(50)

        current = df.iloc[-1]
        previous = df.iloc[-2]

        ema_fast = current["ema_fast"]
        ema_slow = current["ema_slow"]
        rsi = current["rsi"]

        # Volume confirmation
        volume_ratio = 0.0
        if "volume" in df.columns and df["volume"].sum() > 0:
            avg_vol = df["volume"].rolling(20).mean().iloc[-1]
            if avg_vol > 0:
                volume_ratio = current["volume"] / avg_vol

        bullish_cross = (previous["ema_fast"] <= previous["ema_slow"]) and (ema_fast > ema_slow)
        bearish_cross = (previous["ema_fast"] >= previous["ema_slow"]) and (ema_fast < ema_slow)

        if bullish_cross and rsi < settings.RSI_OVERBOUGHT:
            if volume_ratio >= VOLUME_CONFIRMATION_RATIO or volume_ratio == 0:
                signal = TechSignal.BULLISH
                reason = f"EMA cross up, RSI={rsi:.0f}, vol={volume_ratio:.1f}x"
            else:
                signal = TechSignal.NEUTRAL
                reason = f"EMA cross up but low volume ({volume_ratio:.1f}x)"
        elif bearish_cross and rsi > settings.RSI_OVERSOLD:
            if volume_ratio >= VOLUME_CONFIRMATION_RATIO or volume_ratio == 0:
                signal = TechSignal.BEARISH
                reason = f"EMA cross down, RSI={rsi:.0f}, vol={volume_ratio:.1f}x"
            else:
                signal = TechSignal.NEUTRAL
                reason = f"EMA cross down but low volume ({volume_ratio:.1f}x)"
        else:
            signal = TechSignal.NEUTRAL
            reason = f"No crossover, RSI={rsi:.0f}"

        return TechnicalResult(
            signal=signal, ema_fast=ema_fast, ema_slow=ema_slow,
            rsi=rsi, last_close=current["close"], volume_ratio=volume_ratio,
            reason=reason,
        )

    @staticmethod
    def _signals_agree(sentiment_signal: Signal, tech_signal: TechSignal) -> bool:
        if sentiment_signal == Signal.BULLISH and tech_signal == TechSignal.BULLISH:
            return True
        if sentiment_signal == Signal.BEARISH and tech_signal == TechSignal.BEARISH:
            return True
        return False
