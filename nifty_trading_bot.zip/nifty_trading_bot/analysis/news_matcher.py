"""
Maps news items to specific stocks or sectors based on keyword matching.
Also provides stock-specific sentiment aggregation.
"""

import re
from collections import defaultdict
from dataclasses import dataclass
from typing import List, Dict, Optional
from config.instruments import NIFTY50_STOCKS, SECTOR_KEYWORDS
from analysis.sentiment import FinancialSentimentAnalyzer, Signal, AggregateSentiment
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class StockNewsMatch:
    symbol: str
    news_item: object  # NewsItem
    match_type: str  # "direct" or "sector"
    matched_keyword: str
    score: float  # match relevance (direct=2.0, sector=1.0)


class NewsMatcher:
    def __init__(self):
        # Build reverse index: keyword -> (symbol, match_type)
        self._keyword_index = {}
        for symbol, info in NIFTY50_STOCKS.items():
            for kw in info["keywords"]:
                self._keyword_index[kw.lower()] = (symbol, "direct", 2.0)

        for sector, keywords in SECTOR_KEYWORDS.items():
            for kw in keywords:
                # Don't overwrite direct matches
                if kw.lower() not in self._keyword_index:
                    self._keyword_index[kw.lower()] = (sector, "sector", 1.0)

        # Sort keywords by length (longest first) for greedy matching
        self._sorted_keywords = sorted(self._keyword_index.keys(), key=len, reverse=True)

    def match_news(self, news_items: list) -> Dict[str, List[StockNewsMatch]]:
        """
        Match news items to stocks. Returns dict of symbol -> list of matches.
        Sector matches are expanded to all stocks in that sector.
        """
        matches = defaultdict(list)

        for item in news_items:
            text = f"{item.title} {item.summary}".lower()
            matched_symbols = set()

            for kw in self._sorted_keywords:
                if kw in text:
                    target, match_type, score = self._keyword_index[kw]

                    if match_type == "direct":
                        if target not in matched_symbols:
                            matches[target].append(StockNewsMatch(
                                symbol=target,
                                news_item=item,
                                match_type="direct",
                                matched_keyword=kw,
                                score=score,
                            ))
                            matched_symbols.add(target)
                    elif match_type == "sector":
                        # Expand sector to all stocks in that sector
                        for symbol, info in NIFTY50_STOCKS.items():
                            if info["sector"] == target and symbol not in matched_symbols:
                                matches[symbol].append(StockNewsMatch(
                                    symbol=symbol,
                                    news_item=item,
                                    match_type="sector",
                                    matched_keyword=kw,
                                    score=score,
                                ))

        return dict(matches)

    def get_stock_sentiments(self, news_items: list,
                             sentiment_analyzer: FinancialSentimentAnalyzer
                             ) -> Dict[str, dict]:
        """
        Returns sentiment analysis per stock, sorted by signal strength.

        Returns dict of symbol -> {
            "sentiment": AggregateSentiment,
            "direct_news_count": int,
            "sector_news_count": int,
            "signal_strength": float  (composite score for ranking)
        }
        """
        matches = self.match_news(news_items)
        stock_sentiments = {}

        for symbol, stock_matches in matches.items():
            if not stock_matches:
                continue

            # Get unique news items for this stock
            seen_ids = set()
            unique_items = []
            direct_count = 0
            sector_count = 0

            for match in stock_matches:
                item_id = match.news_item.id
                if item_id not in seen_ids:
                    seen_ids.add(item_id)
                    unique_items.append(match.news_item)
                    if match.match_type == "direct":
                        direct_count += 1
                    else:
                        sector_count += 1

            # Need at least 1 direct mention or 2 sector mentions
            if direct_count == 0 and sector_count < 2:
                continue

            sentiment = sentiment_analyzer.analyze_batch(unique_items)

            # Signal strength: combines sentiment confidence, news volume, and directness
            strength = (
                abs(sentiment.weighted_score) *
                sentiment.confidence *
                (1.0 + direct_count * 0.5 + sector_count * 0.2)
            )

            if sentiment.overall_signal != Signal.NEUTRAL:
                stock_sentiments[symbol] = {
                    "sentiment": sentiment,
                    "direct_news_count": direct_count,
                    "sector_news_count": sector_count,
                    "signal_strength": strength,
                }

        return stock_sentiments
