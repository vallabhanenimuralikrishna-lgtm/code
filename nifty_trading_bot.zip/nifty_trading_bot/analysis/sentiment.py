from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import List
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class Signal(Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


@dataclass
class SentimentResult:
    title: str
    compound_score: float
    signal: Signal
    confidence: float


@dataclass
class AggregateSentiment:
    overall_signal: Signal
    average_score: float
    weighted_score: float
    item_count: int
    bullish_count: int
    bearish_count: int
    confidence: float


# Financial keyword boosting for VADER
BULLISH_KEYWORDS = {
    "rally": 2.5, "surge": 2.8, "bullish": 2.5, "breakout": 2.0,
    "recovery": 1.8, "upgrade": 2.0, "outperform": 2.0, "beat": 1.5,
    "strong": 1.5, "boom": 2.5, "accumulate": 1.8, "buying": 1.5,
    "gains": 1.5, "soars": 2.5, "jumps": 2.0, "climbs": 1.5,
    "upbeat": 1.8, "optimistic": 1.5, "stimulus": 2.0,
}

BEARISH_KEYWORDS = {
    "crash": -3.5, "plunge": -3.0, "bearish": -2.5, "breakdown": -2.0,
    "recession": -3.0, "downgrade": -2.0, "underperform": -2.0,
    "miss": -1.5, "weak": -1.5, "panic": -3.0, "crisis": -3.0,
    "selloff": -2.8, "tumbles": -2.5, "slumps": -2.0, "drops": -1.5,
    "falls": -1.5, "fears": -2.0, "inflation": -1.5, "war": -2.5,
    "sanctions": -2.0, "volatility": -1.0,
}


class FinancialSentimentAnalyzer:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()
        # Boost VADER lexicon with financial terms
        self.analyzer.lexicon.update(BULLISH_KEYWORDS)
        self.analyzer.lexicon.update(BEARISH_KEYWORDS)

    def analyze(self, news_item) -> SentimentResult:
        text = f"{news_item.title}. {news_item.summary}"
        scores = self.analyzer.polarity_scores(text)
        compound = scores["compound"]

        if compound >= settings.SENTIMENT_BULLISH_THRESHOLD:
            signal = Signal.BULLISH
        elif compound <= settings.SENTIMENT_BEARISH_THRESHOLD:
            signal = Signal.BEARISH
        else:
            signal = Signal.NEUTRAL

        return SentimentResult(
            title=news_item.title,
            compound_score=compound,
            signal=signal,
            confidence=abs(compound),
        )

    def analyze_batch(self, items, lookback_minutes: int = None) -> AggregateSentiment:
        lookback = lookback_minutes or settings.SENTIMENT_LOOKBACK_MINUTES
        cutoff = datetime.now() - timedelta(minutes=lookback)

        # Filter to recent items
        recent = [item for item in items if item.fetched_at >= cutoff]

        if len(recent) < settings.MIN_NEWS_ITEMS_FOR_SIGNAL:
            return AggregateSentiment(
                overall_signal=Signal.NEUTRAL,
                average_score=0.0,
                weighted_score=0.0,
                item_count=len(recent),
                bullish_count=0,
                bearish_count=0,
                confidence=0.0,
            )

        results = [self.analyze(item) for item in recent]

        # Recency-weighted scoring (newer items weight more)
        now = datetime.now()
        total_weight = 0.0
        weighted_sum = 0.0
        for item, result in zip(recent, results):
            age_minutes = (now - item.fetched_at).total_seconds() / 60
            weight = max(0.1, 1.0 - (age_minutes / lookback))
            weighted_sum += result.compound_score * weight
            total_weight += weight

        weighted_score = weighted_sum / total_weight if total_weight > 0 else 0.0
        average_score = sum(r.compound_score for r in results) / len(results)
        bullish_count = sum(1 for r in results if r.signal == Signal.BULLISH)
        bearish_count = sum(1 for r in results if r.signal == Signal.BEARISH)

        if weighted_score >= settings.SENTIMENT_BULLISH_THRESHOLD:
            overall = Signal.BULLISH
        elif weighted_score <= settings.SENTIMENT_BEARISH_THRESHOLD:
            overall = Signal.BEARISH
        else:
            overall = Signal.NEUTRAL

        confidence = min(1.0, abs(weighted_score))

        return AggregateSentiment(
            overall_signal=overall,
            average_score=average_score,
            weighted_score=weighted_score,
            item_count=len(recent),
            bullish_count=bullish_count,
            bearish_count=bearish_count,
            confidence=confidence,
        )
