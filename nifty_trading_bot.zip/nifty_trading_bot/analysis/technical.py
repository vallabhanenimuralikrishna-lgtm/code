from dataclasses import dataclass
from enum import Enum
import pandas as pd
import numpy as np
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)

VOLUME_CONFIRMATION_RATIO = 1.5  # Current volume must be >= 1.5x 20-period average


class TechSignal(Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


@dataclass
class TechnicalResult:
    signal: TechSignal
    ema_fast: float
    ema_slow: float
    rsi: float
    last_close: float
    volume_ratio: float  # current_volume / avg_volume_20
    reason: str


class TechnicalAnalyzer:
    def __init__(self, market_data):
        self.market_data = market_data

    def get_signal(self) -> TechnicalResult:
        df = self.market_data.get_candles()

        if df.empty or len(df) < settings.EMA_SLOW + 5:
            return TechnicalResult(
                signal=TechSignal.NEUTRAL,
                ema_fast=0, ema_slow=0, rsi=0, last_close=0,
                volume_ratio=0,
                reason="Insufficient candle data",
            )

        # Calculate indicators
        df["ema_fast"] = self._ema(df["close"], settings.EMA_FAST)
        df["ema_slow"] = self._ema(df["close"], settings.EMA_SLOW)
        df["rsi"] = self._rsi(df["close"], settings.RSI_PERIOD)

        current = df.iloc[-1]
        previous = df.iloc[-2]

        ema_fast = current["ema_fast"]
        ema_slow = current["ema_slow"]
        prev_fast = previous["ema_fast"]
        prev_slow = previous["ema_slow"]
        rsi = current["rsi"]
        last_close = current["close"]

        # Volume confirmation
        volume_ratio = 0.0
        if "volume" in df.columns and df["volume"].sum() > 0:
            avg_vol = df["volume"].rolling(20).mean().iloc[-1]
            if avg_vol > 0:
                volume_ratio = current["volume"] / avg_vol

        # Detect crossover
        bullish_cross = (prev_fast <= prev_slow) and (ema_fast > ema_slow)
        bearish_cross = (prev_fast >= prev_slow) and (ema_fast < ema_slow)

        if bullish_cross and rsi < settings.RSI_OVERBOUGHT:
            if volume_ratio >= VOLUME_CONFIRMATION_RATIO or volume_ratio == 0:
                signal = TechSignal.BULLISH
                reason = (
                    f"EMA golden cross (fast={ema_fast:.1f} > slow={ema_slow:.1f}), "
                    f"RSI={rsi:.1f}, vol={volume_ratio:.1f}x"
                )
            else:
                signal = TechSignal.NEUTRAL
                reason = (
                    f"EMA cross up but low volume ({volume_ratio:.1f}x < "
                    f"{VOLUME_CONFIRMATION_RATIO}x required)"
                )
        elif bearish_cross and rsi > settings.RSI_OVERSOLD:
            if volume_ratio >= VOLUME_CONFIRMATION_RATIO or volume_ratio == 0:
                signal = TechSignal.BEARISH
                reason = (
                    f"EMA death cross (fast={ema_fast:.1f} < slow={ema_slow:.1f}), "
                    f"RSI={rsi:.1f}, vol={volume_ratio:.1f}x"
                )
            else:
                signal = TechSignal.NEUTRAL
                reason = (
                    f"EMA cross down but low volume ({volume_ratio:.1f}x < "
                    f"{VOLUME_CONFIRMATION_RATIO}x required)"
                )
        else:
            signal = TechSignal.NEUTRAL
            trend = "above" if ema_fast > ema_slow else "below"
            reason = f"No crossover (EMA fast {trend} slow), RSI={rsi:.1f}"

        logger.debug(f"Technical: {signal.value} - {reason}")
        return TechnicalResult(
            signal=signal,
            ema_fast=ema_fast,
            ema_slow=ema_slow,
            rsi=rsi,
            last_close=last_close,
            volume_ratio=volume_ratio,
            reason=reason,
        )

    @staticmethod
    def _ema(series: pd.Series, period: int) -> pd.Series:
        return series.ewm(span=period, adjust=False).mean()

    @staticmethod
    def _rsi(series: pd.Series, period: int) -> pd.Series:
        delta = series.diff()
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.ewm(span=period, adjust=False).mean()
        avg_loss = loss.ewm(span=period, adjust=False).mean()
        rs = avg_gain / avg_loss.replace(0, np.nan)
        rsi = 100 - (100 / (1 + rs))
        return rsi.fillna(50)
