# Nifty 50 Futures Trading Bot

## What This Is
Intraday trading bot for NSE futures (Nifty index + 48 Nifty 50 stock futures) via Zerodha Kite Connect API. Combines news sentiment (VADER) with EMA crossover + volume confirmation for entry signals.

## Quick Reference

### Run
```bash
python main.py          # Start bot (uses .env for config)
```

### Project Layout
- `trading/` — Order execution, position management, risk controls
- `analysis/` — Sentiment, technical indicators, signal combining, instrument selection
- `data/` — News fetching (RSS), market data (Kite API candles/LTP)
- `config/` — Settings (.env), instruments (Nifty 50 stocks), NSE holidays

### Key Files
- `main.py` — Entry point, main trading loop
- `trading/strategy.py` — Orchestrator: manages positions, enters/exits trades
- `trading/risk_manager.py` — All risk limits (daily loss, SL, trailing stop, cooldown)
- `trading/position_manager.py` — Multi-position tracking (Dict keyed by trading_symbol)
- `analysis/signal_combiner.py` — Combines sentiment + technical into BUY/SELL/HOLD/EXIT

### Critical Rules
- Both sentiment AND technical signals must agree before entry
- Every entry MUST have an SL-M stop-loss order placed immediately
- Paper trade new features before live trading
- Never enter trades before 09:20 or after 15:10 IST
- Max 2 simultaneous positions, max 6 trades/day, max Rs 2,000 daily loss

### Slash Commands
- `/trading-dev` — Full trading application development guide (architecture, patterns, rules)

### Testing Changes
```bash
python -m py_compile trading/strategy.py   # Syntax check
python -c "from config import settings; print(settings.MAX_TRADES_PER_DAY)"  # Config check
```
