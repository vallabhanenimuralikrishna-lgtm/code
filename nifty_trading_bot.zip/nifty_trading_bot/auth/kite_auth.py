import os
import threading
import webbrowser
import logging
from urllib.parse import urlparse, parse_qs
from kiteconnect import KiteConnect
from flask import Flask, request as flask_request
from config import settings
from auth.token_store import TokenStore
from utils.logger import get_logger

logger = get_logger(__name__)


class KiteAuthManager:
    def __init__(self):
        self.kite = KiteConnect(api_key=settings.KITE_API_KEY)
        self.token_store = TokenStore()
        self._request_token = None
        self._auth_event = threading.Event()

    def get_kite_client(self) -> KiteConnect:
        # Try stored token first
        access_token = self.token_store.load()
        if access_token:
            self.kite.set_access_token(access_token)
            if self._is_token_valid():
                logger.info("Using stored access token (valid)")
                return self.kite
            logger.info("Stored token is invalid, re-authenticating")

        # Need fresh login
        request_token = self._get_request_token()
        access_token = self._exchange_token(request_token)
        self.kite.set_access_token(access_token)
        self.token_store.save(access_token)

        profile = self.kite.profile()
        logger.info(f"Authenticated as: {profile['user_name']} ({profile['user_id']})")
        return self.kite

    def _is_token_valid(self) -> bool:
        try:
            self.kite.profile()
            return True
        except Exception:
            return False

    def _get_request_token(self) -> str:
        login_url = self.kite.login_url()
        logger.info(f"Login URL: {login_url}")

        # Try automatic capture via local Flask server
        try:
            return self._start_redirect_server(login_url)
        except Exception as e:
            logger.warning(f"Auto-capture failed ({e}), falling back to manual")
            return self._manual_token_capture(login_url)

    def _start_redirect_server(self, login_url: str) -> str:
        app = Flask(__name__)
        # Suppress Flask request logs
        flask_log = logging.getLogger("werkzeug")
        flask_log.setLevel(logging.ERROR)

        @app.route("/callback")
        def callback():
            self._request_token = flask_request.args.get("request_token")
            if self._request_token:
                self._auth_event.set()
                return (
                    "<html><body style='font-family:Arial;text-align:center;padding:50px'>"
                    "<h2 style='color:green'>Login Successful!</h2>"
                    "<p>You can close this tab. The bot is starting...</p>"
                    "</body></html>"
                )
            return "<h2>Error: No request token received</h2>", 400

        # Run Flask in background thread
        server_thread = threading.Thread(
            target=lambda: app.run(port=5000, debug=False, use_reloader=False),
            daemon=True,
        )
        server_thread.start()

        # Notify user - this shows up even when launched by Task Scheduler
        print("\n" + "=" * 60)
        print("  ZERODHA LOGIN REQUIRED")
        print("=" * 60)
        print()
        print("  Your browser should open automatically.")
        print("  Log in with your Zerodha credentials.")
        print("  The bot will start after you log in.")
        print()
        print("  If browser didn't open, visit:")
        print(f"  {login_url}")
        print()
        print("  Waiting for login (5 min timeout)...")
        print("=" * 60 + "\n")

        # Try to open browser
        try:
            webbrowser.open(login_url)
        except Exception:
            pass  # If browser fails (headless), user will see the URL in console

        # Also show Windows notification if possible
        self._show_windows_notification("Nifty Bot: Login Required",
                                        "Open browser and log in to Zerodha")

        # Wait for callback (5 min timeout - gives user time even if AFK)
        if self._auth_event.wait(timeout=300):
            return self._request_token
        raise TimeoutError("Login timed out after 5 minutes")

    def _manual_token_capture(self, login_url: str) -> str:
        print("\n" + "=" * 60)
        print("MANUAL LOGIN REQUIRED")
        print(f"1. Open this URL: {login_url}")
        print("2. Log in with your Zerodha credentials")
        print("3. After login, copy the FULL redirect URL from your browser")
        print("4. Paste it below")
        print("=" * 60)

        redirect_url = input("\nPaste the redirect URL here: ").strip()
        parsed = urlparse(redirect_url)
        params = parse_qs(parsed.query)
        request_token = params.get("request_token", [None])[0]

        if not request_token:
            raise ValueError("Could not extract request_token from URL")
        return request_token

    def _exchange_token(self, request_token: str) -> str:
        data = self.kite.generate_session(request_token, api_secret=settings.KITE_API_SECRET)
        access_token = data["access_token"]
        logger.info("Successfully obtained access token")
        return access_token

    @staticmethod
    def _show_windows_notification(title: str, message: str):
        """Show a Windows toast notification to alert the user."""
        try:
            from ctypes import windll
            windll.user32.MessageBeep(0x00000040)  # Play notification sound
        except Exception:
            pass
        # Also try PowerShell toast notification
        try:
            import subprocess
            ps_cmd = (
                f'[Windows.UI.Notifications.ToastNotificationManager, '
                f'Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null; '
                f'$template = [Windows.UI.Notifications.ToastNotificationManager]::'
                f'GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02); '
                f'$text = $template.GetElementsByTagName("text"); '
                f'$text[0].AppendChild($template.CreateTextNode("{title}")) | Out-Null; '
                f'$text[1].AppendChild($template.CreateTextNode("{message}")) | Out-Null; '
                f'$notify = [Windows.UI.Notifications.ToastNotification]::new($template); '
                f'[Windows.UI.Notifications.ToastNotificationManager]::'
                f'CreateToastNotifier("Nifty Bot").Show($notify)'
            )
            subprocess.Popen(
                ["powershell", "-Command", ps_cmd],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass
