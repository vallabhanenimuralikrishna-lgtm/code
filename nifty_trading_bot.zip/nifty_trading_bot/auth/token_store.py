import json
import os
from datetime import date, datetime
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class TokenStore:
    def __init__(self):
        self.token_file = settings.TOKEN_FILE
        os.makedirs(os.path.dirname(self.token_file), exist_ok=True)

    def save(self, access_token: str):
        data = {
            "access_token": access_token,
            "created_at": datetime.now().isoformat(),
            "valid_date": date.today().isoformat(),
        }
        with open(self.token_file, "w") as f:
            json.dump(data, f, indent=2)
        logger.info("Access token saved for today")

    def load(self):
        if not os.path.exists(self.token_file):
            return None
        try:
            with open(self.token_file, "r") as f:
                data = json.load(f)
            if data.get("valid_date") == date.today().isoformat():
                logger.info("Found valid access token for today")
                return data["access_token"]
            logger.info("Stored token is from a previous day, needs refresh")
            return None
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Corrupt token file: {e}")
            return None
