from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict
from config import settings
from trading.brokerage import calculate_brokerage
from utils.logger import get_logger, log_trade

logger = get_logger(__name__)


@dataclass
class Position:
    trading_symbol: str  # e.g., "RELIANCE26APRFUT" or "NIFTY26APRFUT"
    direction: str  # "LONG" or "SHORT"
    entry_price: float
    quantity: int
    entry_time: datetime
    stop_loss_price: float
    sl_order_id: str
    entry_signal: str
    instrument_type: str = "index"  # "index" or "stock"
    unrealized_pnl: float = 0.0

    def update_pnl(self, current_price: float):
        if self.direction == "LONG":
            self.unrealized_pnl = (current_price - self.entry_price) * self.quantity
        else:
            self.unrealized_pnl = (self.entry_price - current_price) * self.quantity


@dataclass
class CompletedTrade:
    direction: str
    entry_price: float
    exit_price: float
    quantity: int
    gross_pnl: float
    charges: float
    pnl: float  # net P&L after charges
    entry_signal: str
    exit_reason: str
    entry_time: datetime
    exit_time: datetime
    duration_seconds: int


class PositionManager:
    def __init__(self):
        self.open_positions: Dict[str, Position] = {}  # keyed by trading_symbol
        self.daily_trades: List[CompletedTrade] = []
        self.daily_realized_pnl: float = 0.0

    def open_position(self, trading_symbol: str, direction: str, entry_price: float,
                      quantity: int, stop_loss_price: float, sl_order_id: str,
                      entry_signal: str, instrument_type: str = "index"):
        pos = Position(
            trading_symbol=trading_symbol,
            direction=direction,
            entry_price=entry_price,
            quantity=quantity,
            entry_time=datetime.now(),
            stop_loss_price=stop_loss_price,
            sl_order_id=sl_order_id,
            entry_signal=entry_signal,
            instrument_type=instrument_type,
        )
        self.open_positions[trading_symbol] = pos
        logger.info(
            f"Position opened: {trading_symbol} {direction} {quantity}x @ {entry_price} "
            f"SL={stop_loss_price} | {entry_signal}"
        )

    def close_position(self, trading_symbol: str, exit_price: float,
                       exit_reason: str) -> Optional[CompletedTrade]:
        pos = self.open_positions.get(trading_symbol)
        if not pos:
            return None

        if pos.direction == "LONG":
            gross_pnl = (exit_price - pos.entry_price) * pos.quantity
        else:
            gross_pnl = (pos.entry_price - exit_price) * pos.quantity

        charges_breakdown = calculate_brokerage(
            pos.entry_price, exit_price, pos.quantity, pos.direction,
            pos.instrument_type
        )
        charges = charges_breakdown["total_charges"]
        net_pnl = gross_pnl - charges

        duration = int((datetime.now() - pos.entry_time).total_seconds())

        trade = CompletedTrade(
            direction=pos.direction,
            entry_price=pos.entry_price,
            exit_price=exit_price,
            quantity=pos.quantity,
            gross_pnl=gross_pnl,
            charges=charges,
            pnl=net_pnl,
            entry_signal=pos.entry_signal,
            exit_reason=exit_reason,
            entry_time=pos.entry_time,
            exit_time=datetime.now(),
            duration_seconds=duration,
        )

        self.daily_trades.append(trade)
        self.daily_realized_pnl += net_pnl
        del self.open_positions[trading_symbol]

        logger.info(
            f"Position closed: {trading_symbol} {trade.direction} @ {exit_price} | "
            f"Gross=Rs {gross_pnl:.0f} | Charges=Rs {charges:.0f} | "
            f"Net P&L=Rs {net_pnl:.0f} | {exit_reason} | Duration={duration}s"
        )
        log_trade(
            trade.direction, trade.entry_price, trade.exit_price,
            trade.quantity, trade.pnl, trade.entry_signal,
            trade.exit_reason, trade.duration_seconds,
        )
        return trade

    def has_open_position(self) -> bool:
        return len(self.open_positions) > 0

    def has_room_for_new_position(self) -> bool:
        return len(self.open_positions) < settings.MAX_OPEN_POSITIONS

    def has_position_for(self, trading_symbol: str) -> bool:
        return trading_symbol in self.open_positions

    def get_position(self, trading_symbol: str) -> Optional[Position]:
        return self.open_positions.get(trading_symbol)

    def get_all_open_symbols(self) -> List[str]:
        return list(self.open_positions.keys())

    @property
    def current_position(self) -> Optional[Position]:
        """Backward compat: returns first open position (for logging)."""
        if self.open_positions:
            return next(iter(self.open_positions.values()))
        return None

    def get_position_direction(self) -> Optional[str]:
        if self.open_positions:
            return next(iter(self.open_positions.values())).direction
        return None

    def update_ltp(self, trading_symbol: str, price: float):
        pos = self.open_positions.get(trading_symbol)
        if pos:
            pos.update_pnl(price)

    def get_total_unrealized_pnl(self) -> float:
        return sum(p.unrealized_pnl for p in self.open_positions.values())

    def get_daily_summary(self) -> dict:
        total_trades = len(self.daily_trades)
        winning = sum(1 for t in self.daily_trades if t.pnl > 0)
        losing = sum(1 for t in self.daily_trades if t.pnl < 0)
        total_gross = sum(t.gross_pnl for t in self.daily_trades)
        total_charges = sum(t.charges for t in self.daily_trades)
        gross_profit = sum(t.gross_pnl for t in self.daily_trades if t.gross_pnl > 0)
        gross_loss = sum(t.gross_pnl for t in self.daily_trades if t.gross_pnl < 0)

        return {
            "total_trades": total_trades,
            "winning_trades": winning,
            "losing_trades": losing,
            "win_rate": f"{(winning / total_trades * 100):.0f}%" if total_trades else "N/A",
            "gross_profit": f"Rs {gross_profit:.0f}",
            "gross_loss": f"Rs {gross_loss:.0f}",
            "total_gross_pnl": f"Rs {total_gross:.0f}",
            "total_charges": f"Rs {total_charges:.0f}",
            "net_pnl": f"Rs {self.daily_realized_pnl:.0f}",
        }

    def reset_daily(self):
        self.open_positions.clear()
        self.daily_trades.clear()
        self.daily_realized_pnl = 0.0
