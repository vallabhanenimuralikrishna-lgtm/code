import time
from datetime import datetime
from analysis.sentiment import FinancialSentimentAnalyzer, Signal
from analysis.technical import TechnicalAnalyzer
from analysis.signal_combiner import SignalCombiner, Action
from analysis.instrument_selector import InstrumentSelector
from data.news_fetcher import NewsFetcher
from data.deduplicator import NewsDeduplicator
from data.market_data import MarketData, MultiInstrumentData, get_current_futures_symbol
from trading.risk_manager import RiskManager
from trading.order_manager import OrderManager
from trading.position_manager import PositionManager
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class TradingStrategy:
    def __init__(self, kite):
        self.kite = kite

        # Data
        self.news_fetcher = NewsFetcher()
        self.deduplicator = NewsDeduplicator()
        self.multi_data = MultiInstrumentData(kite)
        self.multi_data.load_instruments()

        # Nifty futures symbol (for fallback and position tracking)
        self.nifty_symbol = get_current_futures_symbol(kite)

        # Legacy single-instrument data (for backward compat)
        self.market_data = MarketData(kite)
        self.market_data.initialize(self.nifty_symbol)

        # Analysis
        self.sentiment_analyzer = FinancialSentimentAnalyzer()
        self.technical_analyzer = TechnicalAnalyzer(self.market_data)
        self.signal_combiner = SignalCombiner()
        self.instrument_selector = InstrumentSelector(kite, self.multi_data)

        # Trading
        self.risk_manager = RiskManager()
        self.position_manager = PositionManager()

        # State: maps trading_symbol -> OrderManager for each open position
        self._news_items = []
        self._last_news_fetch = 0
        self._open_instruments = {}  # {trading_symbol: OrderManager}

    def run_iteration(self):
        """Single iteration of the trading loop."""
        now = datetime.now()
        current_time = now.strftime("%H:%M")

        # Check if we should square off all positions
        should_exit, exit_reason = self.risk_manager.should_square_off()
        if should_exit and self.position_manager.has_open_position():
            logger.info(f"Auto square-off: {exit_reason}")
            self._close_all_positions(exit_reason)
            return

        # Don't enter new trades after trading end time
        if current_time >= settings.TRADING_END:
            return

        # Fetch news (throttled)
        if time.time() - self._last_news_fetch >= settings.NEWS_FETCH_INTERVAL:
            self._fetch_news()
            self._last_news_fetch = time.time()

        # Manage all open positions (trailing stops, SL checks, exit signals)
        if self.position_manager.has_open_position():
            self._manage_open_positions()

        # Check if we have room for a new position
        if not self.position_manager.has_room_for_new_position():
            return

        # No room or risk check
        can_trade, reason = self.risk_manager.can_trade()
        if not can_trade:
            logger.debug(f"Cannot trade: {reason}")
            return

        # Scan for best opportunity, excluding symbols we already hold
        candidate = self.instrument_selector.select_best(
            self._news_items, settings.CAPITAL
        )

        if candidate and not self.position_manager.has_position_for(candidate.trading_symbol):
            logger.info(
                f"SIGNAL: {candidate.symbol} {candidate.direction} | "
                f"strength={candidate.signal_strength:.2f} | "
                f"margin=Rs {candidate.margin_required:.0f}"
            )
            self._enter_position(candidate)

    def _manage_open_positions(self):
        """Manage all open positions - trailing stop, SL check, exit signals."""
        # Iterate over a copy of keys since we may close positions during iteration
        for trading_symbol in list(self.position_manager.get_all_open_symbols()):
            pos = self.position_manager.get_position(trading_symbol)
            om = self._open_instruments.get(trading_symbol)
            if not pos or not om:
                continue

            # Get current price
            ltp = self.multi_data.get_ltp(trading_symbol)
            if ltp <= 0:
                continue

            self.position_manager.update_ltp(trading_symbol, ltp)

            # Update trailing stop
            new_sl = self.risk_manager.calculate_trailing_stop(
                pos.entry_price, ltp, pos.direction, pos.stop_loss_price,
                pos.instrument_type
            )
            if new_sl != pos.stop_loss_price:
                if om.modify_stop_loss(pos.sl_order_id, new_sl):
                    pos.stop_loss_price = new_sl
                    logger.info(f"Trailing stop updated: {trading_symbol} SL={new_sl}")

            # Check if SL was hit
            sl_status = om.get_order_status(pos.sl_order_id)
            if sl_status.get("status") == "COMPLETE":
                exit_price = sl_status.get("average_price", ltp)
                trade = self.position_manager.close_position(
                    trading_symbol, exit_price, "stop_loss"
                )
                if trade:
                    self.risk_manager.record_trade_result(trade.pnl)
                self._open_instruments.pop(trading_symbol, None)
                continue

            # Check for signal reversal (exit if sentiment flips)
            sentiment = self.sentiment_analyzer.analyze_batch(self._news_items)
            candles = self.multi_data.get_candles(trading_symbol)
            if not candles.empty and len(candles) >= settings.EMA_SLOW + 5:
                tech = self.instrument_selector._compute_technical(candles)
                decision = self.signal_combiner.combine(
                    sentiment, tech, True, pos.direction
                )
                if decision.action == Action.EXIT:
                    logger.info(f"Signal reversal on {trading_symbol}: {decision.reason}")
                    self._close_position(trading_symbol, decision.reason)

    def _fetch_news(self):
        new_items = self.news_fetcher.fetch_all()
        added = 0
        for item in new_items:
            if not self.deduplicator.is_duplicate(item):
                self.deduplicator.add(item)
                self._news_items.append(item)
                added += 1
        if len(self._news_items) > 150:
            self._news_items = self._news_items[-150:]
        if added:
            logger.info(f"News: +{added} new items (total buffer: {len(self._news_items)})")

    def _enter_position(self, candidate):
        """Enter a position on the selected instrument."""
        # Risk check
        can_trade, reason = self.risk_manager.can_trade()
        if not can_trade:
            logger.info(f"Trade blocked: {reason}")
            return

        # Create order manager for this instrument
        om = OrderManager(self.kite, candidate.trading_symbol)

        # Get position size (may be scaled up on win streaks)
        base_qty = candidate.lot_size
        scale = self.risk_manager.get_position_scale()
        qty = base_qty * scale

        order_direction = "BUY" if candidate.direction == "LONG" else "SELL"

        # Place entry order
        entry_order_id = om.place_entry_order(order_direction, qty)
        if not entry_order_id:
            logger.error(f"Entry order failed for {candidate.symbol}")
            return

        # Wait briefly and get fill price (skip wait in paper mode)
        if not settings.PAPER_TRADE:
            time.sleep(2)
        entry_price = om.get_filled_price(entry_order_id)
        if entry_price == 0:
            logger.error("Entry not filled, cancelling")
            om.cancel_order(entry_order_id)
            return

        # Calculate stop-loss (risk_manager handles Nifty vs stock logic + per-trade cap)
        instrument_type = "index" if candidate.symbol == "NIFTY" else "stock"
        sl_price = self.risk_manager.calculate_stop_loss(
            entry_price, candidate.direction, qty, instrument_type
        )

        sl_order_id = om.place_stop_loss(candidate.direction, qty, sl_price)
        if not sl_order_id:
            logger.error("SL order failed - closing position immediately")
            om.square_off_all(qty, candidate.direction)
            return

        # Record position
        self.position_manager.open_position(
            trading_symbol=candidate.trading_symbol,
            direction=candidate.direction,
            entry_price=entry_price,
            quantity=qty,
            stop_loss_price=sl_price,
            sl_order_id=sl_order_id,
            entry_signal=candidate.reason,
            instrument_type=instrument_type,
        )
        self._open_instruments[candidate.trading_symbol] = om

        scale_msg = f" (SCALED {scale}x)" if scale > 1 else ""
        logger.info(
            f"ENTERED: {candidate.symbol} ({candidate.trading_symbol}) "
            f"{candidate.direction} {qty}x @ {entry_price} SL={sl_price}{scale_msg}"
        )

    def _close_position(self, trading_symbol: str, reason: str):
        """Close a specific position by trading symbol."""
        pos = self.position_manager.get_position(trading_symbol)
        if not pos:
            return

        om = self._open_instruments.get(trading_symbol)
        if not om:
            logger.error(f"No order manager for {trading_symbol}")
            return

        exit_order_id = om.square_off_all(pos.quantity, pos.direction)

        if exit_order_id:
            if not settings.PAPER_TRADE:
                time.sleep(2)
            exit_price = om.get_filled_price(exit_order_id)
            if exit_price == 0:
                exit_price = self.multi_data.get_ltp(trading_symbol)
        else:
            exit_price = self.multi_data.get_ltp(trading_symbol)

        trade = self.position_manager.close_position(trading_symbol, exit_price, reason)
        if trade:
            self.risk_manager.record_trade_result(trade.pnl)

        self._open_instruments.pop(trading_symbol, None)

    def _close_all_positions(self, reason: str):
        """Close all open positions (for square-off / shutdown)."""
        for trading_symbol in list(self.position_manager.get_all_open_symbols()):
            self._close_position(trading_symbol, reason)

    def get_daily_summary(self) -> dict:
        summary = self.position_manager.get_daily_summary()
        summary["daily_pnl_from_risk"] = f"Rs {self.risk_manager.daily_pnl:.0f}"
        return summary

    def reset_daily(self):
        self.position_manager.reset_daily()
        self.risk_manager.reset_daily_state()
        self.deduplicator.clear_all()
        self._news_items.clear()
        self._last_news_fetch = 0
        self._open_instruments.clear()
