import time
import uuid
from kiteconnect import KiteConnect
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)

RETRY_ATTEMPTS = 3
RETRY_DELAY = 1


class OrderManager:
    def __init__(self, kite: KiteConnect, trading_symbol: str):
        self.kite = kite
        self.symbol = trading_symbol
        self._active_orders = {}  # order_id -> order info
        self._paper_mode = settings.PAPER_TRADE
        self._paper_prices = {}  # order_id -> simulated fill price

    def place_entry_order(self, direction: str, qty: int) -> str:
        """Place a market entry order. direction: BUY or SELL."""
        if self._paper_mode:
            return self._paper_entry(direction, qty)

        transaction_type = self.kite.TRANSACTION_TYPE_BUY if direction == "BUY" else self.kite.TRANSACTION_TYPE_SELL

        for attempt in range(RETRY_ATTEMPTS):
            try:
                order_id = self.kite.place_order(
                    variety=self.kite.VARIETY_REGULAR,
                    exchange=settings.EXCHANGE,
                    tradingsymbol=self.symbol,
                    transaction_type=transaction_type,
                    quantity=qty,
                    product=self.kite.PRODUCT_MIS,
                    order_type=self.kite.ORDER_TYPE_MARKET,
                )
                logger.info(f"Entry order placed: {direction} {qty} {self.symbol} | order_id={order_id}")
                self._active_orders[order_id] = {
                    "type": "ENTRY",
                    "direction": direction,
                    "quantity": qty,
                }
                return order_id
            except Exception as e:
                logger.error(f"Entry order failed (attempt {attempt + 1}): {e}")
                if attempt < RETRY_ATTEMPTS - 1:
                    time.sleep(RETRY_DELAY)
        return None

    def place_stop_loss(self, direction: str, qty: int, trigger_price: float) -> str:
        """Place SL-M stop-loss order. Direction is the EXIT direction (opposite of position)."""
        if self._paper_mode:
            return self._paper_stop_loss(direction, qty, trigger_price)

        transaction_type = self.kite.TRANSACTION_TYPE_SELL if direction == "LONG" else self.kite.TRANSACTION_TYPE_BUY

        for attempt in range(RETRY_ATTEMPTS):
            try:
                order_id = self.kite.place_order(
                    variety=self.kite.VARIETY_REGULAR,
                    exchange=settings.EXCHANGE,
                    tradingsymbol=self.symbol,
                    transaction_type=transaction_type,
                    quantity=qty,
                    product=self.kite.PRODUCT_MIS,
                    order_type=self.kite.ORDER_TYPE_SLM,
                    trigger_price=trigger_price,
                )
                logger.info(f"SL order placed: trigger={trigger_price} qty={qty} | order_id={order_id}")
                self._active_orders[order_id] = {
                    "type": "STOP_LOSS",
                    "direction": "SELL" if direction == "LONG" else "BUY",
                    "trigger_price": trigger_price,
                    "quantity": qty,
                }
                return order_id
            except Exception as e:
                logger.error(f"SL order failed (attempt {attempt + 1}): {e}")
                if attempt < RETRY_ATTEMPTS - 1:
                    time.sleep(RETRY_DELAY)
        return None

    def modify_stop_loss(self, order_id: str, new_trigger_price: float) -> bool:
        """Modify existing SL-M order trigger price (for trailing stop)."""
        if self._paper_mode:
            if order_id in self._active_orders:
                self._active_orders[order_id]["trigger_price"] = new_trigger_price
                logger.info(f"[PAPER] SL modified: {order_id} -> {new_trigger_price}")
            return True

        try:
            self.kite.modify_order(
                variety=self.kite.VARIETY_REGULAR,
                order_id=order_id,
                trigger_price=new_trigger_price,
            )
            logger.info(f"SL modified: order_id={order_id} new_trigger={new_trigger_price}")
            if order_id in self._active_orders:
                self._active_orders[order_id]["trigger_price"] = new_trigger_price
            return True
        except Exception as e:
            logger.error(f"SL modify failed: {e}")
            return False

    def cancel_order(self, order_id: str) -> bool:
        if self._paper_mode:
            self._active_orders.pop(order_id, None)
            logger.info(f"[PAPER] Order cancelled: {order_id}")
            return True

        try:
            self.kite.cancel_order(
                variety=self.kite.VARIETY_REGULAR,
                order_id=order_id,
            )
            logger.info(f"Order cancelled: {order_id}")
            self._active_orders.pop(order_id, None)
            return True
        except Exception as e:
            logger.error(f"Cancel failed for {order_id}: {e}")
            return False

    def square_off_all(self, qty: int, position_direction: str) -> str:
        """Market order to close position. Cancel pending SL first."""
        # Cancel all pending SL orders
        for oid, info in list(self._active_orders.items()):
            if info["type"] == "STOP_LOSS":
                self.cancel_order(oid)

        if self._paper_mode:
            return self._paper_square_off(qty, position_direction)

        # Place market exit order
        exit_direction = "SELL" if position_direction == "LONG" else "BUY"
        transaction_type = (self.kite.TRANSACTION_TYPE_SELL
                            if exit_direction == "SELL"
                            else self.kite.TRANSACTION_TYPE_BUY)

        for attempt in range(RETRY_ATTEMPTS):
            try:
                order_id = self.kite.place_order(
                    variety=self.kite.VARIETY_REGULAR,
                    exchange=settings.EXCHANGE,
                    tradingsymbol=self.symbol,
                    transaction_type=transaction_type,
                    quantity=qty,
                    product=self.kite.PRODUCT_MIS,
                    order_type=self.kite.ORDER_TYPE_MARKET,
                )
                logger.info(f"Square-off order: {exit_direction} {qty} | order_id={order_id}")
                self._active_orders.clear()
                return order_id
            except Exception as e:
                logger.error(f"Square-off failed (attempt {attempt + 1}): {e}")
                if attempt < RETRY_ATTEMPTS - 1:
                    time.sleep(RETRY_DELAY)
        return None

    def get_order_status(self, order_id: str) -> dict:
        if self._paper_mode:
            return self._paper_order_status(order_id)

        try:
            orders = self.kite.order_history(order_id)
            if orders:
                return orders[-1]  # Latest status
        except Exception as e:
            logger.error(f"Order status check failed: {e}")
        return {}

    def get_filled_price(self, order_id: str) -> float:
        if self._paper_mode:
            return self._paper_prices.get(order_id, 0.0)

        status = self.get_order_status(order_id)
        if status.get("status") == "COMPLETE":
            return status.get("average_price", 0.0)
        return 0.0

    # ===== Paper Trading Methods =====

    def _paper_entry(self, direction: str, qty: int) -> str:
        """Simulate entry order using current LTP."""
        order_id = f"PAPER-{uuid.uuid4().hex[:8]}"
        try:
            key = f"{settings.EXCHANGE}:{self.symbol}"
            quote = self.kite.ltp(key)
            price = quote[key]["last_price"]
        except Exception:
            price = 0.0

        self._paper_prices[order_id] = price
        self._active_orders[order_id] = {
            "type": "ENTRY",
            "direction": direction,
            "quantity": qty,
            "status": "COMPLETE",
            "average_price": price,
        }
        logger.info(f"[PAPER] Entry: {direction} {qty} {self.symbol} @ {price} | {order_id}")
        return order_id

    def _paper_stop_loss(self, direction: str, qty: int, trigger_price: float) -> str:
        """Simulate SL order placement."""
        order_id = f"PAPER-SL-{uuid.uuid4().hex[:8]}"
        self._active_orders[order_id] = {
            "type": "STOP_LOSS",
            "direction": "SELL" if direction == "LONG" else "BUY",
            "trigger_price": trigger_price,
            "quantity": qty,
            "status": "OPEN",
        }
        logger.info(f"[PAPER] SL placed: trigger={trigger_price} | {order_id}")
        return order_id

    def _paper_square_off(self, qty: int, position_direction: str) -> str:
        """Simulate square-off using current LTP."""
        order_id = f"PAPER-EXIT-{uuid.uuid4().hex[:8]}"
        try:
            key = f"{settings.EXCHANGE}:{self.symbol}"
            quote = self.kite.ltp(key)
            price = quote[key]["last_price"]
        except Exception:
            price = 0.0

        self._paper_prices[order_id] = price
        self._active_orders.clear()
        exit_dir = "SELL" if position_direction == "LONG" else "BUY"
        logger.info(f"[PAPER] Square-off: {exit_dir} {qty} {self.symbol} @ {price} | {order_id}")
        return order_id

    def _paper_order_status(self, order_id: str) -> dict:
        """Check if paper SL was triggered by comparing LTP to trigger price."""
        info = self._active_orders.get(order_id, {})
        if info.get("type") != "STOP_LOSS":
            return info

        trigger_price = info.get("trigger_price", 0)
        direction = info.get("direction", "")

        try:
            key = f"{settings.EXCHANGE}:{self.symbol}"
            quote = self.kite.ltp(key)
            ltp = quote[key]["last_price"]
        except Exception:
            return {"status": "OPEN"}

        # Check if SL was triggered
        triggered = False
        if direction == "SELL" and ltp <= trigger_price:  # Long position SL
            triggered = True
        elif direction == "BUY" and ltp >= trigger_price:  # Short position SL
            triggered = True

        if triggered:
            self._paper_prices[order_id] = trigger_price
            info["status"] = "COMPLETE"
            info["average_price"] = trigger_price
            logger.info(f"[PAPER] SL TRIGGERED: {self.symbol} @ {trigger_price}")
            return {"status": "COMPLETE", "average_price": trigger_price}

        return {"status": "OPEN"}
