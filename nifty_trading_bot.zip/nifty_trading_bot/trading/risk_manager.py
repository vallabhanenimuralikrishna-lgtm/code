import time
from datetime import datetime
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class RiskManager:
    def __init__(self):
        self.reset_daily_state()

    def reset_daily_state(self):
        self.daily_pnl = 0.0
        self.trade_count = 0
        self.consecutive_losses = 0
        self.consecutive_wins = 0
        self.last_loss_time = None
        self._halted = False
        self._halt_reason = ""

    def can_trade(self) -> tuple:
        """Returns (allowed: bool, reason: str)."""
        if self._halted:
            return False, f"Trading halted: {self._halt_reason}"

        if self.daily_pnl <= -settings.MAX_DAILY_LOSS:
            self._halted = True
            self._halt_reason = f"Max daily loss reached (Rs {self.daily_pnl:.0f})"
            logger.warning(self._halt_reason)
            return False, self._halt_reason

        if self.daily_pnl >= settings.DAILY_PROFIT_TARGET:
            self._halted = True
            self._halt_reason = f"Daily profit target reached! (Rs {self.daily_pnl:.0f})"
            logger.info(self._halt_reason)
            return False, self._halt_reason

        if self.trade_count >= settings.MAX_TRADES_PER_DAY:
            return False, f"Max trades/day reached ({self.trade_count})"

        if self.consecutive_losses >= settings.MAX_CONSECUTIVE_LOSSES:
            self._halted = True
            self._halt_reason = f"Max consecutive losses ({self.consecutive_losses})"
            logger.warning(self._halt_reason)
            return False, self._halt_reason

        # Cooldown after loss
        if self.last_loss_time:
            elapsed = time.time() - self.last_loss_time
            if elapsed < settings.COOLDOWN_SECONDS:
                remaining = int(settings.COOLDOWN_SECONDS - elapsed)
                return False, f"Loss cooldown: {remaining}s remaining"

        return True, "OK"

    def calculate_stop_loss(self, entry_price: float, direction: str,
                           quantity: int = None, instrument_type: str = "index") -> float:
        """
        Calculate stop-loss price.
        - Nifty: fixed 30 points (Rs 750 per trade)
        - Stocks: % based, capped at MAX_LOSS_PER_TRADE
        """
        if instrument_type == "index":
            sl_points = settings.STOP_LOSS_POINTS
        else:
            # Stock futures: calculate SL points based on max loss cap
            qty = quantity or settings.LOT_SIZE
            # Max loss / quantity = max points we can risk
            sl_points = settings.MAX_LOSS_PER_TRADE / qty
            # Also cap at 1% of price as upper bound
            max_pct_sl = entry_price * 0.01
            sl_points = min(sl_points, max_pct_sl)
            sl_points = round(sl_points, 1)
            logger.info(
                f"Stock SL: {sl_points} pts (max loss Rs {sl_points * qty:.0f} on {qty} qty)"
            )

        if direction == "LONG":
            return round(entry_price - sl_points, 1)
        else:
            return round(entry_price + sl_points, 1)

    def calculate_trailing_stop(self, entry_price: float, current_price: float,
                                direction: str, current_sl: float,
                                instrument_type: str = "index") -> float:
        """Returns updated stop-loss price if trailing should activate/update."""
        if instrument_type == "index":
            activation = settings.TRAILING_ACTIVATION_POINTS
            trail = settings.TRAILING_STOP_POINTS
        else:
            # Stock futures: trailing in proportion to entry price
            activation = entry_price * 0.005  # Activate after 0.5% in profit
            trail = entry_price * 0.004       # Trail by 0.4%

        if direction == "LONG":
            profit_points = current_price - entry_price
            if profit_points >= activation:
                new_sl = current_price - trail
                return round(max(new_sl, current_sl), 1)
        else:
            profit_points = entry_price - current_price
            if profit_points >= activation:
                new_sl = current_price + trail
                return round(min(new_sl, current_sl), 1)
        return current_sl

    def record_trade_result(self, pnl: float):
        self.daily_pnl += pnl
        self.trade_count += 1

        if pnl < 0:
            self.consecutive_losses += 1
            self.consecutive_wins = 0
            self.last_loss_time = time.time()
            logger.info(f"Trade loss: Rs {pnl:.0f} | Consecutive losses: {self.consecutive_losses}")
        else:
            self.consecutive_losses = 0
            self.consecutive_wins += 1
            self.last_loss_time = None
            logger.info(f"Trade profit: Rs {pnl:.0f} | Consecutive wins: {self.consecutive_wins}")

        logger.info(f"Daily P&L: Rs {self.daily_pnl:.0f} | Trades: {self.trade_count}")

    def should_square_off(self) -> tuple:
        """Returns (should_exit: bool, reason: str)."""
        now = datetime.now()
        current_time = now.strftime("%H:%M")

        if current_time >= settings.SQUARE_OFF_TIME:
            return True, f"Square-off time reached ({settings.SQUARE_OFF_TIME})"

        if self.daily_pnl >= settings.DAILY_PROFIT_TARGET:
            return True, f"Daily target reached (Rs {self.daily_pnl:.0f})"

        if self.daily_pnl <= -settings.MAX_DAILY_LOSS:
            return True, f"Max daily loss breached (Rs {self.daily_pnl:.0f})"

        return False, ""

    def get_position_size(self) -> int:
        """Returns quantity to trade (lot size * number of lots)."""
        return settings.LOT_SIZE * settings.POSITION_SIZE_LOTS * self.get_position_scale()

    def get_position_scale(self) -> int:
        """Returns position multiplier based on win streak. 2x after 2+ consecutive wins."""
        if self.consecutive_wins >= 2:
            logger.info(f"Win streak scaling: 2x position (consecutive wins: {self.consecutive_wins})")
            return 2
        return 1
