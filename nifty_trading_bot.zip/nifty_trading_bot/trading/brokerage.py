"""
Zerodha brokerage and charges calculator for Futures (MIS).

Charges per executed order:
- Brokerage: Rs 20 per order (flat, capped, both buy and sell)
- STT: 0.02% on sell side (both index and stock futures)
- Exchange transaction: 0.0019% for index futures, 0.0019% for stock futures (NSE)
- GST: 18% on (brokerage + exchange transaction charges)
- SEBI charges: Rs 10 per crore of turnover
- Stamp duty: 0.002% on buy side (stock futures), 0.002% (index futures)

Note: STT for intraday futures is 0.02% on sell side only.
For delivery/NRML stock futures, STT is 0.02% on both sides.
Since we use MIS (intraday), it's sell-side only.

Reference: https://zerodha.com/charges
"""


def calculate_brokerage(entry_price: float, exit_price: float,
                        quantity: int, direction: str,
                        instrument_type: str = "index") -> dict:
    """
    Calculate total charges for a complete round-trip futures trade.

    Args:
        entry_price: Price at which position was entered
        exit_price: Price at which position was exited
        quantity: Number of units traded
        direction: "LONG" or "SHORT"
        instrument_type: "index" for Nifty/BankNifty, "stock" for stock futures

    Returns:
        dict with breakdown of all charges and total
    """
    buy_price = entry_price if direction == "LONG" else exit_price
    sell_price = exit_price if direction == "LONG" else entry_price

    buy_turnover = buy_price * quantity
    sell_turnover = sell_price * quantity
    total_turnover = buy_turnover + sell_turnover

    # Brokerage: Rs 20 per order, 2 orders (entry + exit)
    # Capped: if 0.03% of turnover < Rs 20, use the lower value
    brokerage_per_order = min(20.0, buy_turnover * 0.0003)
    brokerage = brokerage_per_order + min(20.0, sell_turnover * 0.0003)

    # STT: 0.02% on sell side for futures (MIS intraday)
    stt = sell_turnover * 0.0002

    # Exchange transaction charges (NSE)
    # Index futures: 0.0019%, Stock futures: 0.0019%
    exchange_txn = total_turnover * 0.000019

    # GST: 18% on (brokerage + exchange transaction charges)
    gst = (brokerage + exchange_txn) * 0.18

    # SEBI charges: Rs 10 per crore
    sebi = total_turnover * (10 / 10_000_000)

    # Stamp duty: 0.002% on buy side
    stamp_duty = buy_turnover * 0.00002

    # DP charges: nil for futures (no delivery)
    total_charges = brokerage + stt + exchange_txn + gst + sebi + stamp_duty

    return {
        "brokerage": round(brokerage, 2),
        "stt": round(stt, 2),
        "exchange_txn": round(exchange_txn, 2),
        "gst": round(gst, 2),
        "sebi": round(sebi, 2),
        "stamp_duty": round(stamp_duty, 2),
        "total_charges": round(total_charges, 2),
        "buy_turnover": round(buy_turnover, 2),
        "sell_turnover": round(sell_turnover, 2),
        "instrument_type": instrument_type,
    }


def estimate_breakeven_points(entry_price: float, quantity: int,
                              instrument_type: str = "index") -> float:
    """
    Estimate how many points the price needs to move to cover charges.
    Useful for setting minimum profit targets.
    """
    # Estimate charges assuming exit at same price (worst case)
    charges = calculate_brokerage(entry_price, entry_price, quantity,
                                  "LONG", instrument_type)
    total = charges["total_charges"]
    # Points needed = total_charges / quantity
    return round(total / quantity, 2)
