@echo off
title Nifty Trading Bot
cd /d "%~dp0"

echo ============================================
echo   Nifty Futures Trading Bot - Starting...
echo ============================================
echo.

:: Check if Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.10+ and add to PATH.
    pause
    exit /b 1
)

:: Check if .env exists
if not exist ".env" (
    echo ERROR: .env file not found.
    echo Copy .env.example to .env and fill in your Kite API credentials:
    echo   copy .env.example .env
    pause
    exit /b 1
)

:: Check if dependencies are installed
python -c "import kiteconnect" >nul 2>&1
if errorlevel 1 (
    echo Installing dependencies...
    pip install -r requirements.txt
    echo.
)

:: Run the bot
echo Starting bot at %date% %time%
echo.
python main.py

:: Keep window open if there was an error
if errorlevel 1 (
    echo.
    echo Bot exited with error. Check logs\bot.log for details.
    pause
)
