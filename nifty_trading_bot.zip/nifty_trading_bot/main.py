"""
Nifty 50 Futures Trading Bot
Connects to Zerodha via Kite Connect API.
Trades based on news sentiment + EMA crossover technical signals.

DISCLAIMER: Trading futures involves substantial risk of loss.
A 10% daily return target is unrealistic - this bot uses it as an
auto-exit ceiling. Realistic expectations: 1-2% daily or less.
PAPER TRADE FIRST before using real money.
"""

import sys
import os
import signal
import time
from datetime import datetime, date, timedelta

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import settings
from config.holidays import is_trading_day
from auth.kite_auth import KiteAuthManager
from trading.strategy import TradingStrategy
from utils.logger import setup_logging, get_logger

logger = None
strategy = None


def graceful_shutdown(signum=None, frame=None):
    """Handle Ctrl+C / SIGTERM - square off and exit."""
    if logger:
        logger.info("Shutdown signal received")
    if strategy and strategy.position_manager.has_open_position():
        count = len(strategy.position_manager.open_positions)
        logger.warning(f"Squaring off {count} open position(s) before exit...")
        strategy._close_all_positions("manual_shutdown")

    _print_daily_report()
    sys.exit(0)


def _print_daily_report():
    if not strategy:
        return
    summary = strategy.get_daily_summary()
    logger.info("=" * 50)
    logger.info("DAILY TRADING REPORT")
    logger.info("=" * 50)
    for key, value in summary.items():
        logger.info(f"  {key}: {value}")
    logger.info("=" * 50)


def wait_until(target_time_str: str):
    """Sleep until a target time (HH:MM format) today."""
    now = datetime.now()
    h, m = map(int, target_time_str.split(":"))
    target = now.replace(hour=h, minute=m, second=0, microsecond=0)
    if target <= now:
        return
    wait_seconds = (target - now).total_seconds()
    logger.info(f"Waiting until {target_time_str} ({int(wait_seconds)}s)...")
    time.sleep(wait_seconds)


def is_trading_hours() -> bool:
    current_time = datetime.now().strftime("%H:%M")
    return settings.TRADING_START <= current_time < settings.MARKET_CLOSE


def next_trading_day(from_date: date = None) -> date:
    d = (from_date or date.today()) + timedelta(days=1)
    while not is_trading_day(d):
        d += timedelta(days=1)
    return d


def main():
    global logger, strategy

    # Setup logging
    setup_logging()
    logger = get_logger("main")

    # Determine current phase
    if settings.PAPER_TRADE:
        mode = "PAPER TRADE"
        phase = "Phase 1" if not settings.ENABLE_STOCK_FUTURES else "Phase 1 (stocks enabled)"
    elif not settings.ENABLE_STOCK_FUTURES:
        mode = "LIVE - NIFTY ONLY"
        phase = "Phase 2"
    else:
        mode = "LIVE - NIFTY + STOCKS"
        phase = "Phase 3"

    logger.info("=" * 60)
    logger.info("  NIFTY FUTURES TRADING BOT")
    logger.info(f"  Mode: {mode} | {phase}")
    logger.info("=" * 60)

    if settings.PAPER_TRADE:
        logger.info("*** PAPER TRADE MODE - No real orders will be placed ***")
        logger.info("*** Signals and P&L are simulated using live market prices ***")
    else:
        logger.warning(
            "LIVE TRADING MODE - Real orders will be placed! "
            "Ensure you have sufficient margin."
        )

    logger.info(f"Capital: Rs {settings.CAPITAL:,}")
    logger.info(f"Daily target: Rs {settings.DAILY_PROFIT_TARGET:,}")
    logger.info(f"Max daily loss: Rs {settings.MAX_DAILY_LOSS:,}")
    logger.info(f"Nifty SL: {settings.STOP_LOSS_POINTS} pts (Rs {settings.STOP_LOSS_POINTS * settings.LOT_SIZE})")
    logger.info(f"Stock SL cap: Rs {settings.MAX_LOSS_PER_TRADE} per trade")
    logger.info(f"Max trades/day: {settings.MAX_TRADES_PER_DAY}")
    logger.info(f"Max open positions: {settings.MAX_OPEN_POSITIONS}")
    logger.info(f"Max consecutive losses: {settings.MAX_CONSECUTIVE_LOSSES}")
    logger.info(f"Cooldown after loss: {settings.COOLDOWN_SECONDS}s")
    instruments = "NIFTY + 48 stock futures" if settings.ENABLE_STOCK_FUTURES else "NIFTY only"
    logger.info(f"Instruments: {instruments}")

    # Check API credentials
    if not settings.KITE_API_KEY or not settings.KITE_API_SECRET:
        logger.error(
            "KITE_API_KEY and KITE_API_SECRET must be set. "
            "Copy .env.example to .env and fill in your credentials."
        )
        sys.exit(1)

    # Check if today is a trading day
    today = date.today()
    if not is_trading_day(today):
        next_day = next_trading_day(today)
        logger.info(f"Today ({today}) is not a trading day. Next session: {next_day}")
        sys.exit(0)

    # Check if market hours already passed
    current_time = datetime.now().strftime("%H:%M")
    if current_time >= settings.MARKET_CLOSE:
        logger.info("Market has already closed for today.")
        sys.exit(0)

    # Authenticate with Kite
    logger.info("Authenticating with Kite Connect...")
    auth_manager = KiteAuthManager()
    try:
        kite = auth_manager.get_kite_client()
    except Exception as e:
        logger.error(f"Authentication failed: {e}")
        sys.exit(1)

    # Initialize multi-instrument strategy (Nifty + 50 stock futures)
    logger.info("Loading instruments (Nifty + Nifty 50 stock futures)...")
    strategy = TradingStrategy(kite)
    logger.info(f"Nifty futures: {strategy.nifty_symbol}")
    logger.info("Scanning universe: NIFTY index + 48 Nifty 50 stock futures")

    # Register shutdown handlers
    signal.signal(signal.SIGINT, graceful_shutdown)
    signal.signal(signal.SIGTERM, graceful_shutdown)

    # Wait for market open if early
    if current_time < settings.TRADING_START:
        logger.info(f"Market not yet open. Waiting until {settings.TRADING_START}...")
        # Pre-market: start fetching news early
        if current_time < settings.MARKET_OPEN:
            wait_until(settings.MARKET_OPEN)
        logger.info("Pre-market: Fetching initial news...")
        strategy._fetch_news()
        wait_until(settings.TRADING_START)

    logger.info(">>> TRADING SESSION STARTED <<<")

    # Main trading loop
    iteration = 0
    while is_trading_hours():
        iteration += 1
        try:
            strategy.run_iteration()

            # Periodic status log
            if iteration % 10 == 0:  # Every ~2.5 minutes (at 15s interval)
                pm = strategy.position_manager
                if pm.has_open_position():
                    for sym, p in pm.open_positions.items():
                        logger.info(
                            f"[STATUS] {sym} {p.direction} @ {p.entry_price} | "
                            f"Unrealized: Rs {p.unrealized_pnl:.0f} | "
                            f"SL: {p.stop_loss_price}"
                        )
                    logger.info(
                        f"[STATUS] {len(pm.open_positions)} position(s) open | "
                        f"Total unrealized: Rs {pm.get_total_unrealized_pnl():.0f} | "
                        f"Day P&L: Rs {strategy.risk_manager.daily_pnl:.0f}"
                    )
                else:
                    logger.info(
                        f"[STATUS] No position | Scanning all instruments | "
                        f"Day P&L: Rs {strategy.risk_manager.daily_pnl:.0f} | "
                        f"Trades: {strategy.risk_manager.trade_count}"
                    )

        except KeyboardInterrupt:
            graceful_shutdown()
        except Exception as e:
            logger.error(f"Error in trading loop: {e}", exc_info=True)
            time.sleep(5)  # Brief pause on error

        time.sleep(settings.MAIN_LOOP_INTERVAL)

    # End of day
    logger.info(">>> TRADING SESSION ENDED <<<")

    # Final square-off if any positions remain
    if strategy.position_manager.has_open_position():
        count = len(strategy.position_manager.open_positions)
        logger.warning(f"End-of-day: Squaring off {count} remaining position(s)")
        strategy._close_all_positions("end_of_day_square_off")

    _print_daily_report()
    logger.info("Bot shutting down. See you next trading day!")


if __name__ == "__main__":
    main()
