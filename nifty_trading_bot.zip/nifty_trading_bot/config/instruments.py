"""
Nifty 50 F&O stock universe with lot sizes and news keywords.

Lot sizes are updated periodically by NSE. Verify from:
https://www.nseindia.com/products-services/equity-derivatives-lot-size

The bot will auto-fetch actual lot sizes from Kite instruments API,
this list serves as fallback and keyword mapping.
"""

# symbol -> {lot_size (fallback), keywords for news matching, sector}
NIFTY50_STOCKS = {
    "RELIANCE": {
        "lot_size": 250,
        "keywords": ["reliance", "ril", "jio", "mukesh ambani", "reliance industries"],
        "sector": "energy",
    },
    "TCS": {
        "lot_size": 175,
        "keywords": ["tcs", "tata consultancy", "tata consulting"],
        "sector": "it",
    },
    "HDFCBANK": {
        "lot_size": 550,
        "keywords": ["hdfc bank", "hdfcbank"],
        "sector": "banking",
    },
    "INFY": {
        "lot_size": 400,
        "keywords": ["infosys", "infy", "narayana murthy", "salil parekh"],
        "sector": "it",
    },
    "ICICIBANK": {
        "lot_size": 700,
        "keywords": ["icici bank", "icicibank"],
        "sector": "banking",
    },
    "HINDUNILVR": {
        "lot_size": 300,
        "keywords": ["hindustan unilever", "hul", "hindunilvr"],
        "sector": "fmcg",
    },
    "ITC": {
        "lot_size": 1600,
        "keywords": ["itc", "itc limited", "itc hotels"],
        "sector": "fmcg",
    },
    "SBIN": {
        "lot_size": 750,
        "keywords": ["sbi", "state bank", "sbin"],
        "sector": "banking",
    },
    "BHARTIARTL": {
        "lot_size": 475,
        "keywords": ["bharti airtel", "airtel", "bhartiartl"],
        "sector": "telecom",
    },
    "KOTAKBANK": {
        "lot_size": 400,
        "keywords": ["kotak", "kotak mahindra", "kotakbank"],
        "sector": "banking",
    },
    "LT": {
        "lot_size": 150,
        "keywords": ["larsen", "l&t", "larsen toubro", "larsen & toubro"],
        "sector": "infrastructure",
    },
    "HCLTECH": {
        "lot_size": 350,
        "keywords": ["hcl tech", "hcltech", "hcl technologies"],
        "sector": "it",
    },
    "AXISBANK": {
        "lot_size": 625,
        "keywords": ["axis bank", "axisbank"],
        "sector": "banking",
    },
    "ASIANPAINT": {
        "lot_size": 300,
        "keywords": ["asian paints", "asianpaint"],
        "sector": "consumer",
    },
    "MARUTI": {
        "lot_size": 100,
        "keywords": ["maruti", "maruti suzuki"],
        "sector": "auto",
    },
    "SUNPHARMA": {
        "lot_size": 700,
        "keywords": ["sun pharma", "sun pharmaceutical", "sunpharma"],
        "sector": "pharma",
    },
    "TATAMOTORS": {
        "lot_size": 1400,
        "keywords": ["tata motors", "tatamotors"],
        "sector": "auto",
    },
    "TITAN": {
        "lot_size": 175,
        "keywords": ["titan", "titan company", "tanishq"],
        "sector": "consumer",
    },
    "BAJFINANCE": {
        "lot_size": 125,
        "keywords": ["bajaj finance", "bajfinance"],
        "sector": "finance",
    },
    "WIPRO": {
        "lot_size": 1500,
        "keywords": ["wipro"],
        "sector": "it",
    },
    "ULTRACEMCO": {
        "lot_size": 100,
        "keywords": ["ultratech", "ultratech cement", "ultracemco"],
        "sector": "cement",
    },
    "NTPC": {
        "lot_size": 2800,
        "keywords": ["ntpc"],
        "sector": "power",
    },
    "TATASTEEL": {
        "lot_size": 1100,
        "keywords": ["tata steel", "tatasteel"],
        "sector": "metals",
    },
    "POWERGRID": {
        "lot_size": 2700,
        "keywords": ["power grid", "powergrid"],
        "sector": "power",
    },
    "M&M": {
        "lot_size": 350,
        "keywords": ["mahindra", "m&m", "mahindra and mahindra"],
        "sector": "auto",
    },
    "ONGC": {
        "lot_size": 3850,
        "keywords": ["ongc", "oil and natural gas"],
        "sector": "energy",
    },
    "JSWSTEEL": {
        "lot_size": 675,
        "keywords": ["jsw steel", "jswsteel"],
        "sector": "metals",
    },
    "ADANIENT": {
        "lot_size": 500,
        "keywords": ["adani enterprises", "adanient", "adani"],
        "sector": "conglomerate",
    },
    "ADANIPORTS": {
        "lot_size": 1250,
        "keywords": ["adani ports", "adaniports"],
        "sector": "infrastructure",
    },
    "TECHM": {
        "lot_size": 600,
        "keywords": ["tech mahindra", "techm"],
        "sector": "it",
    },
    "COALINDIA": {
        "lot_size": 2100,
        "keywords": ["coal india", "coalindia"],
        "sector": "mining",
    },
    "BAJAJFINSV": {
        "lot_size": 500,
        "keywords": ["bajaj finserv", "bajajfinsv"],
        "sector": "finance",
    },
    "DRREDDY": {
        "lot_size": 125,
        "keywords": ["dr reddy", "drreddy", "dr. reddy"],
        "sector": "pharma",
    },
    "CIPLA": {
        "lot_size": 650,
        "keywords": ["cipla"],
        "sector": "pharma",
    },
    "TATACONSUM": {
        "lot_size": 450,
        "keywords": ["tata consumer", "tataconsum"],
        "sector": "fmcg",
    },
    "DIVISLAB": {
        "lot_size": 150,
        "keywords": ["divis lab", "divi's", "divislab"],
        "sector": "pharma",
    },
    "GRASIM": {
        "lot_size": 350,
        "keywords": ["grasim", "grasim industries"],
        "sector": "cement",
    },
    "INDUSINDBK": {
        "lot_size": 500,
        "keywords": ["indusind bank", "indusindbk"],
        "sector": "banking",
    },
    "HEROMOTOCO": {
        "lot_size": 150,
        "keywords": ["hero motocorp", "hero moto", "heromotoco"],
        "sector": "auto",
    },
    "APOLLOHOSP": {
        "lot_size": 125,
        "keywords": ["apollo hospital", "apollo hospitals", "apollohosp"],
        "sector": "healthcare",
    },
    "HINDALCO": {
        "lot_size": 1075,
        "keywords": ["hindalco"],
        "sector": "metals",
    },
    "EICHERMOT": {
        "lot_size": 175,
        "keywords": ["eicher", "eicher motors", "royal enfield", "eichermot"],
        "sector": "auto",
    },
    "NESTLEIND": {
        "lot_size": 200,
        "keywords": ["nestle india", "nestleind", "nestle"],
        "sector": "fmcg",
    },
    "SBILIFE": {
        "lot_size": 375,
        "keywords": ["sbi life", "sbilife"],
        "sector": "insurance",
    },
    "BPCL": {
        "lot_size": 1800,
        "keywords": ["bpcl", "bharat petroleum"],
        "sector": "energy",
    },
    "BRITANNIA": {
        "lot_size": 100,
        "keywords": ["britannia"],
        "sector": "fmcg",
    },
    "HDFCLIFE": {
        "lot_size": 550,
        "keywords": ["hdfc life", "hdfclife"],
        "sector": "insurance",
    },
    "BAJAJ-AUTO": {
        "lot_size": 75,
        "keywords": ["bajaj auto"],
        "sector": "auto",
    },
}

# Sector-level keywords (for sector-wide news)
SECTOR_KEYWORDS = {
    "banking": ["banking sector", "bank nifty", "rbi", "interest rate", "monetary policy", "credit growth", "npa"],
    "it": ["it sector", "tech sector", "outsourcing", "digital", "h1b", "us recession"],
    "auto": ["auto sector", "automobile", "ev", "electric vehicle", "auto sales"],
    "pharma": ["pharma sector", "pharmaceutical", "fda", "drug approval", "usfda"],
    "energy": ["crude oil", "oil prices", "opec", "petroleum", "energy sector"],
    "metals": ["metal prices", "steel prices", "aluminium", "commodity"],
    "fmcg": ["fmcg", "consumer goods", "rural demand", "consumption"],
    "infrastructure": ["infrastructure", "road construction", "order win", "capex"],
    "telecom": ["telecom", "5g", "arpu", "spectrum", "tariff hike"],
    "finance": ["nbfc", "lending", "fintech", "credit"],
    "power": ["power sector", "electricity", "renewable energy", "solar"],
}
