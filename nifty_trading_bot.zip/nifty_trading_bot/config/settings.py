import os
from dotenv import load_dotenv

load_dotenv()

# === Kite Connect ===
KITE_API_KEY = os.getenv("KITE_API_KEY", "")
KITE_API_SECRET = os.getenv("KITE_API_SECRET", "")
KITE_REDIRECT_URL = os.getenv("KITE_REDIRECT_URL", "http://localhost:5000/callback")
TOKEN_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "token_data.json")

# === Trading Parameters ===
INSTRUMENT = "NIFTY"
EXCHANGE = "NFO"
LOT_SIZE = 25
POSITION_SIZE_LOTS = 1
PRODUCT_TYPE = "MIS"  # Intraday

# === Capital & Risk ===
CAPITAL = int(os.getenv("CAPITAL", "100000"))
MAX_DAILY_LOSS = int(os.getenv("MAX_DAILY_LOSS", "2000"))       # 2% of capital (conservative)
DAILY_PROFIT_TARGET = int(os.getenv("DAILY_PROFIT_TARGET", "3000"))  # Rs 3K realistic target
STOP_LOSS_POINTS = int(os.getenv("STOP_LOSS_POINTS", "30"))
TRAILING_STOP_POINTS = 20
TRAILING_ACTIVATION_POINTS = 10  # Lock in profits sooner (was 15)
MAX_TRADES_PER_DAY = 6          # More opportunities with stock futures enabled
MAX_OPEN_POSITIONS = int(os.getenv("MAX_OPEN_POSITIONS", "2"))  # Allow 2 simultaneous positions
MAX_CONSECUTIVE_LOSSES = 2      # Stop after 2 losses, not 3
COOLDOWN_SECONDS = 300          # 5 min cooldown (was 10 min)

# === Stock Futures Toggle ===
# Set to False to trade only Nifty (recommended for Phase 1-2)
ENABLE_STOCK_FUTURES = os.getenv("ENABLE_STOCK_FUTURES", "true").lower() == "true"

# === Paper Trade Mode ===
# Phase 1: Set true to log signals without placing real orders
# Phase 2+: Set false for live trading
PAPER_TRADE = os.getenv("PAPER_TRADE", "true").lower() == "true"

# === Per-Trade Risk Cap ===
# Max loss allowed per single trade (protects against large stock lot sizes)
MAX_LOSS_PER_TRADE = int(os.getenv("MAX_LOSS_PER_TRADE", "1500"))

# === Market Hours (IST) ===
MARKET_OPEN = "09:15"
TRADING_START = "09:20"
TRADING_END = "15:10"
SQUARE_OFF_TIME = "15:15"
MARKET_CLOSE = "15:30"

# === News & Sentiment ===
NEWS_FETCH_INTERVAL = 30  # Faster news detection (was 60s)
SENTIMENT_LOOKBACK_MINUTES = 30
SENTIMENT_BULLISH_THRESHOLD = 0.25
SENTIMENT_BEARISH_THRESHOLD = -0.25
SENTIMENT_MIN_CONFIDENCE = 0.3
MIN_NEWS_ITEMS_FOR_SIGNAL = 3

# === Technical Analysis ===
CANDLE_INTERVAL = "5minute"
EMA_FAST = 9
EMA_SLOW = 21
RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
TECHNICAL_LOOKBACK_CANDLES = 50

# === Email Daily Report ===
EMAIL_ENABLED = os.getenv("EMAIL_ENABLED", "true").lower() == "true"
EMAIL_TO = os.getenv("EMAIL_TO", "murali8998@gmail.com")
EMAIL_FROM = os.getenv("EMAIL_FROM", "")          # Your Gmail address
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD", "")   # Gmail App Password (NOT your login password)
EMAIL_SMTP_HOST = os.getenv("EMAIL_SMTP_HOST", "smtp.gmail.com")
EMAIL_SMTP_PORT = int(os.getenv("EMAIL_SMTP_PORT", "587"))

# === System ===
MAIN_LOOP_INTERVAL = 15  # React to market faster (was 30s)
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
TIMEZONE = "Asia/Kolkata"
