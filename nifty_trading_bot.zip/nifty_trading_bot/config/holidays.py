from datetime import date

# NSE Holiday Calendar 2026
# Source: https://www.nseindia.com/resources/exchange-communication-holidays
# Update annually from official NSE circular

NSE_HOLIDAYS_2026 = {
    date(2026, 1, 26),   # Republic Day
    date(2026, 3, 10),   # Maha Shivaratri
    date(2026, 3, 30),   # Holi
    date(2026, 4, 2),    # Ram Navami
    date(2026, 4, 3),    # Good Friday
    date(2026, 4, 14),   # Dr. Ambedkar Jayanti
    date(2026, 5, 1),    # May Day
    date(2026, 5, 25),   # Buddha Purnima
    date(2026, 7, 7),    # Muharram
    date(2026, 8, 15),   # Independence Day
    date(2026, 9, 5),    # Milad-un-Nabi
    date(2026, 10, 2),   # Mahatma Gandhi Jayanti
    date(2026, 10, 21),  # Dussehra
    date(2026, 11, 4),   # Diwali (Laxmi Pujan)
    date(2026, 11, 5),   # Diwali (Balipratipada)
    date(2026, 11, 19),  # Guru Nanak Jayanti
    date(2026, 12, 25),  # Christmas
}


def is_nse_holiday(check_date: date) -> bool:
    return check_date in NSE_HOLIDAYS_2026


def is_trading_day(check_date: date) -> bool:
    if check_date.weekday() >= 5:  # Saturday=5, Sunday=6
        return False
    return not is_nse_holiday(check_date)
