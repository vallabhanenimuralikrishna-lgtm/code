import hashlib
import re
from datetime import datetime, timedelta
from utils.logger import get_logger

logger = get_logger(__name__)


class NewsDeduplicator:
    def __init__(self, ttl_hours=4):
        self._seen = {}  # hash -> timestamp
        self._ttl = timedelta(hours=ttl_hours)

    def is_duplicate(self, news_item) -> bool:
        self._clear_old_entries()
        item_hash = self._hash_title(news_item.title)
        if item_hash in self._seen:
            return True
        # Check similarity against recent items
        normalized = self._normalize_title(news_item.title)
        for existing_hash, (existing_title, _) in self._seen.items():
            if self._similarity(normalized, existing_title) > 0.85:
                return True
        return False

    def add(self, news_item):
        item_hash = self._hash_title(news_item.title)
        normalized = self._normalize_title(news_item.title)
        self._seen[item_hash] = (normalized, datetime.now())

    def _hash_title(self, title: str) -> str:
        normalized = self._normalize_title(title)
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]

    def _normalize_title(self, title: str) -> str:
        title = title.lower().strip()
        title = re.sub(r'[^\w\s]', '', title)
        title = re.sub(r'\s+', ' ', title)
        return title

    def _similarity(self, a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        words_a = set(a.split())
        words_b = set(b.split())
        if not words_a or not words_b:
            return 0.0
        intersection = words_a & words_b
        union = words_a | words_b
        return len(intersection) / len(union)

    def _clear_old_entries(self):
        cutoff = datetime.now() - self._ttl
        expired = [h for h, (_, ts) in self._seen.items() if ts < cutoff]
        for h in expired:
            del self._seen[h]

    def clear_all(self):
        self._seen.clear()
