import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import List
import feedparser
import hashlib
from utils.logger import get_logger

logger = get_logger(__name__)

RSS_FEEDS = {
    "moneycontrol": "https://www.moneycontrol.com/rss/marketreports.xml",
    "economictimes": "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",
    "livemint": "https://www.livemint.com/rss/markets",
    "google_news": (
        "https://news.google.com/rss/topics/"
        "CAAqIQgKIhtDQkFTRGdvSUwyMHZNRGx6TVdZU0FtVnVLQUFQAQ"
        "?hl=en-IN&gl=IN&ceid=IN:en"
    ),
}

# Minimum seconds between fetches per source
RATE_LIMITS = {
    "moneycontrol": 60,
    "economictimes": 60,
    "livemint": 60,
    "google_news": 90,
}


@dataclass
class NewsItem:
    title: str
    summary: str
    source: str
    published: datetime
    url: str
    fetched_at: datetime = field(default_factory=datetime.now)

    @property
    def id(self) -> str:
        return hashlib.sha256(f"{self.title}|{self.source}".encode()).hexdigest()[:16]


class NewsFetcher:
    def __init__(self):
        self._last_fetch = {}  # source -> timestamp
        self._backoff = {}  # source -> seconds

    def fetch_all(self) -> List[NewsItem]:
        all_items = []
        for source, url in RSS_FEEDS.items():
            if not self._should_fetch(source):
                continue
            try:
                items = self._fetch_feed(url, source)
                all_items.extend(items)
                self._last_fetch[source] = time.time()
                self._backoff[source] = 0
                if items:
                    logger.debug(f"Fetched {len(items)} items from {source}")
            except Exception as e:
                logger.warning(f"Failed to fetch {source}: {e}")
                current_backoff = self._backoff.get(source, 0)
                self._backoff[source] = min(current_backoff * 2 or 60, 300)
        return all_items

    def _fetch_feed(self, url: str, source: str) -> List[NewsItem]:
        feed = feedparser.parse(url)
        if feed.bozo and not feed.entries:
            raise ValueError(f"Feed parse error: {feed.bozo_exception}")
        items = []
        for entry in feed.entries[:20]:  # Cap at 20 per source
            published = datetime.now()
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                try:
                    published = datetime(*entry.published_parsed[:6])
                except (TypeError, ValueError):
                    pass
            items.append(NewsItem(
                title=entry.get("title", "").strip(),
                summary=entry.get("summary", entry.get("description", "")).strip(),
                source=source,
                published=published,
                url=entry.get("link", ""),
            ))
        return items

    def _should_fetch(self, source: str) -> bool:
        last = self._last_fetch.get(source, 0)
        rate_limit = RATE_LIMITS.get(source, 60)
        backoff = self._backoff.get(source, 0)
        min_interval = max(rate_limit, backoff)
        return (time.time() - last) >= min_interval
