from datetime import datetime, timedelta, date
from typing import Dict, Optional
import pandas as pd
from config import settings
from config.instruments import NIFTY50_STOCKS
from utils.logger import get_logger

logger = get_logger(__name__)

MONTH_MAP = {
    1: "JAN", 2: "FEB", 3: "MAR", 4: "APR",
    5: "MAY", 6: "JUN", 7: "JUL", 8: "AUG",
    9: "SEP", 10: "OCT", 11: "NOV", 12: "DEC",
}


def get_last_thursday(year: int, month: int) -> date:
    """Get the last Thursday of a given month (NSE expiry day)."""
    if month == 12:
        next_month = date(year + 1, 1, 1)
    else:
        next_month = date(year, month + 1, 1)
    last_day = next_month - timedelta(days=1)
    # Walk back to Thursday (weekday 3)
    offset = (last_day.weekday() - 3) % 7
    return last_day - timedelta(days=offset)


def get_current_futures_symbol(kite) -> str:
    """
    Resolve the current month Nifty futures trading symbol.
    If current month expiry has passed, use next month.
    Format: NIFTY{YY}{MMM}FUT (e.g., NIFTY26APRFUT)
    """
    today = date.today()
    year = today.year
    month = today.month

    expiry = get_last_thursday(year, month)
    if today > expiry:
        # Move to next month
        if month == 12:
            year += 1
            month = 1
        else:
            month += 1

    yy = str(year)[-2:]
    mmm = MONTH_MAP[month]
    symbol = f"NIFTY{yy}{mmm}FUT"

    # Verify instrument exists
    try:
        instruments = kite.instruments(settings.EXCHANGE)
        matching = [i for i in instruments if i["tradingsymbol"] == symbol]
        if matching:
            logger.info(f"Trading symbol: {symbol} (token: {matching[0]['instrument_token']})")
            return symbol
        # Fallback: find nearest NIFTY FUT
        nifty_futs = [i for i in instruments
                      if i["tradingsymbol"].startswith("NIFTY")
                      and i["tradingsymbol"].endswith("FUT")
                      and i["expiry"] >= today]
        if nifty_futs:
            nifty_futs.sort(key=lambda x: x["expiry"])
            symbol = nifty_futs[0]["tradingsymbol"]
            logger.info(f"Using nearest futures: {symbol}")
            return symbol
    except Exception as e:
        logger.error(f"Failed to resolve futures symbol: {e}")

    logger.warning(f"Using computed symbol: {symbol} (unverified)")
    return symbol


class MarketData:
    def __init__(self, kite):
        self.kite = kite
        self._instrument_token = None
        self._trading_symbol = None

    def initialize(self, trading_symbol: str):
        self._trading_symbol = trading_symbol
        try:
            instruments = self.kite.instruments(settings.EXCHANGE)
            for inst in instruments:
                if inst["tradingsymbol"] == trading_symbol:
                    self._instrument_token = inst["instrument_token"]
                    break
        except Exception as e:
            logger.error(f"Failed to get instrument token: {e}")

    def get_candles(self, interval: str = None, lookback_candles: int = None) -> pd.DataFrame:
        """Fetch historical candles as a DataFrame."""
        interval = interval or settings.CANDLE_INTERVAL
        lookback = lookback_candles or settings.TECHNICAL_LOOKBACK_CANDLES

        # Calculate from_date based on interval and lookback
        now = datetime.now()
        if "minute" in interval:
            minutes = int(interval.replace("minute", "")) * lookback * 2
            from_date = now - timedelta(minutes=minutes)
        else:
            from_date = now - timedelta(days=lookback * 2)

        try:
            instrument_id = f"{settings.EXCHANGE}:{self._trading_symbol}"
            data = self.kite.historical_data(
                instrument_token=self._instrument_token,
                from_date=from_date,
                to_date=now,
                interval=interval,
            )
            df = pd.DataFrame(data)
            if not df.empty:
                df = df.tail(lookback)
            return df
        except Exception as e:
            logger.error(f"Failed to fetch candles: {e}")
            return pd.DataFrame()

    def get_ltp(self) -> float:
        """Get last traded price."""
        try:
            key = f"{settings.EXCHANGE}:{self._trading_symbol}"
            quote = self.kite.ltp(key)
            return quote[key]["last_price"]
        except Exception as e:
            logger.error(f"Failed to get LTP: {e}")
            return 0.0


def get_stock_futures_symbol(kite, stock_symbol: str) -> Optional[str]:
    """
    Resolve current month stock futures symbol.
    Format: {SYMBOL}{YY}{MMM}FUT (e.g., RELIANCE26APRFUT)
    """
    today = date.today()
    year = today.year
    month = today.month

    expiry = get_last_thursday(year, month)
    if today > expiry:
        if month == 12:
            year += 1
            month = 1
        else:
            month += 1

    yy = str(year)[-2:]
    mmm = MONTH_MAP[month]
    expected_symbol = f"{stock_symbol}{yy}{mmm}FUT"

    return expected_symbol


class MultiInstrumentData:
    """Handles market data for multiple instruments (Nifty + stock futures)."""

    def __init__(self, kite):
        self.kite = kite
        self._instruments_cache = None  # NFO instrument list, fetched once/day
        self._token_cache = {}  # symbol -> instrument_token
        self._lot_size_cache = {}  # symbol -> lot_size from exchange

    def load_instruments(self):
        """Fetch and cache NFO instruments list (call once at startup)."""
        try:
            self._instruments_cache = self.kite.instruments(settings.EXCHANGE)
            # Build token and lot size caches
            for inst in self._instruments_cache:
                sym = inst["tradingsymbol"]
                self._token_cache[sym] = inst["instrument_token"]
                if inst.get("lot_size"):
                    self._lot_size_cache[sym] = inst["lot_size"]
            logger.info(f"Loaded {len(self._instruments_cache)} NFO instruments")
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}")

    def get_instrument_token(self, trading_symbol: str) -> Optional[int]:
        return self._token_cache.get(trading_symbol)

    def get_lot_size(self, stock_symbol: str) -> int:
        """Get lot size for a stock. Tries exchange data first, falls back to config."""
        # Check if we have a futures symbol cached with lot size
        fut_symbol = get_stock_futures_symbol(self.kite, stock_symbol)
        if fut_symbol and fut_symbol in self._lot_size_cache:
            return self._lot_size_cache[fut_symbol]
        # Fallback to our config
        if stock_symbol in NIFTY50_STOCKS:
            return NIFTY50_STOCKS[stock_symbol]["lot_size"]
        if stock_symbol == "NIFTY":
            return settings.LOT_SIZE
        return 25  # safe default

    def get_candles(self, trading_symbol: str, interval: str = None,
                    lookback_candles: int = None) -> pd.DataFrame:
        """Fetch candles for any instrument."""
        interval = interval or settings.CANDLE_INTERVAL
        lookback = lookback_candles or settings.TECHNICAL_LOOKBACK_CANDLES

        token = self.get_instrument_token(trading_symbol)
        if not token:
            logger.warning(f"No token for {trading_symbol}")
            return pd.DataFrame()

        now = datetime.now()
        if "minute" in interval:
            minutes = int(interval.replace("minute", "")) * lookback * 2
            from_date = now - timedelta(minutes=minutes)
        else:
            from_date = now - timedelta(days=lookback * 2)

        try:
            data = self.kite.historical_data(
                instrument_token=token,
                from_date=from_date,
                to_date=now,
                interval=interval,
            )
            df = pd.DataFrame(data)
            if not df.empty:
                df = df.tail(lookback)
            return df
        except Exception as e:
            logger.error(f"Candles failed for {trading_symbol}: {e}")
            return pd.DataFrame()

    def get_ltp(self, trading_symbol: str) -> float:
        try:
            key = f"{settings.EXCHANGE}:{trading_symbol}"
            quote = self.kite.ltp(key)
            return quote[key]["last_price"]
        except Exception as e:
            logger.error(f"LTP failed for {trading_symbol}: {e}")
            return 0.0

    def get_multiple_ltp(self, symbols: list) -> Dict[str, float]:
        """Batch LTP fetch for multiple symbols (max 500 per call on Kite)."""
        keys = [f"{settings.EXCHANGE}:{s}" for s in symbols]
        result = {}
        try:
            # Kite allows up to 500 instruments per LTP call
            for i in range(0, len(keys), 500):
                batch = keys[i:i + 500]
                quotes = self.kite.ltp(batch)
                for key, data in quotes.items():
                    sym = key.split(":")[1]
                    result[sym] = data["last_price"]
        except Exception as e:
            logger.error(f"Batch LTP failed: {e}")
        return result
