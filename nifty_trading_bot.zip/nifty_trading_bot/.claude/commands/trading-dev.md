You are an expert trading application developer. Use the following comprehensive guide when developing, modifying, or debugging this trading bot or building any new trading application features.

---

# Trading Application Development Guide

## 1. Architecture Overview

### Module Structure
```
trading/          Core execution engine (orders, positions, risk)
analysis/         Signal generation (sentiment, technical, combining)
data/             Market data and news ingestion
config/           Settings, instruments, market calendar
auth/             Broker API authentication
utils/            Logging, helpers
```

### Data Flow Pipeline
```
News Feeds (RSS) --> Sentiment Analysis (VADER + financial keywords)
                          |
Market Candles (OHLCV) --> Technical Analysis (EMA crossover + RSI + Volume)
                          |
                    Signal Combiner (both must agree)
                          |
                    Instrument Selector (rank by signal strength)
                          |
                    Risk Manager (daily limits, position sizing)
                          |
                    Order Manager (entry + SL-M stop-loss)
                          |
                    Position Manager (track P&L, trailing stops)
```

### Key Design Principles
- **Dual signal confirmation**: NEVER enter a trade on a single signal. Both sentiment AND technical must agree.
- **Defense in depth**: Multiple risk layers (per-trade cap, daily cap, consecutive loss halt, cooldown).
- **Paper-first**: Every feature must work in paper mode before touching live orders.
- **Fail-safe exits**: Always place SL-M at entry. If SL placement fails, immediately exit the position.

---

## 2. Trading System Design Patterns

### Strategy Pattern
- `TradingStrategy` is the orchestrator. It owns the main loop (`run_iteration()`).
- Each iteration: manage open positions first, then scan for new entries.
- Never block the main loop — all operations should be fast or async.

### Risk Management Layers (innermost to outermost)
1. **Per-trade SL**: Fixed points (index) or percentage-capped (stocks)
2. **Trailing stop**: Activates after X points profit, trails by Y points
3. **Per-trade loss cap**: Rs 1,500 max loss on any single trade
4. **Consecutive loss halt**: Stop trading after N consecutive losses
5. **Loss cooldown**: Wait period after a losing trade
6. **Daily loss cap**: Hard stop when daily P&L hits -Rs 2,000
7. **Daily profit target**: Auto-exit when daily P&L hits +Rs 3,000
8. **Max trades/day**: Cap total number of trades
9. **Time-based square-off**: Close everything before market close

### Order Lifecycle
```
1. Signal generated (BUY/SELL)
2. Risk check: can_trade() → checks all 9 layers above
3. Position size: get_position_size() (may scale on win streaks)
4. Entry: Market order (VARIETY_REGULAR, ORDER_TYPE_MARKET)
5. SL: SL-M order (ORDER_TYPE_SLM with trigger_price)
6. Monitor: Check SL status, update trailing stop, check reversal signals
7. Exit: Square-off via market order (cancel SL first, then place exit)
```

### Multi-Position Management
- Positions stored in `Dict[str, Position]` keyed by `trading_symbol`
- Each position has its own `OrderManager` instance
- Strategy tracks `_open_instruments: Dict[str, OrderManager]`
- Max 2 simultaneous positions (configurable via `MAX_OPEN_POSITIONS`)
- Never open duplicate positions on the same instrument

---

## 3. Indian Market Specifics (NSE/NFO)

### Trading Hours (IST)
| Event | Time |
|-------|------|
| Market Open | 09:15 |
| Trading Start (bot) | 09:20 |
| Trading End (no new entries) | 15:10 |
| Square-off Time | 15:15 |
| Market Close | 15:30 |

### Product Types
- **MIS (Margin Intraday Square-off)**: ~10% margin, must close by EOD. This is what we use.
- **NRML**: Full margin, can carry overnight. Not used.
- **CNC**: Delivery for equity. Not applicable for futures.

### Futures Contract Naming
- **Index**: `NIFTY{YY}{MMM}FUT` → e.g., `NIFTY26APRFUT`
- **Stock**: `{SYMBOL}{YY}{MMM}FUT` → e.g., `RELIANCE26APRFUT`
- Contracts roll monthly. Handle rollover near expiry (last Thursday of month).

### NSE Holidays
- Maintain a holiday calendar in `config/holidays.py`
- Check `is_trading_day(date)` before starting the bot
- Update the calendar annually

### Lot Sizes
- Nifty: 25 units per lot (fixed)
- Stock futures: Varies by stock (50 to 3850 units). Defined in `config/instruments.py`.

---

## 4. Signal Generation Pipeline

### Sentiment Analysis
- **Engine**: VADER (Valence Aware Dictionary and sEntiment Reasoner)
- **Enhancement**: Custom financial keyword boosting (rally=+2.5, crash=-3.5, etc.)
- **Input**: RSS feeds from Moneycontrol, Economic Times, LiveMint, Google News
- **Scoring**: Recency-weighted (newer items count more)
- **Thresholds**: Bullish >= +0.25, Bearish <= -0.25, Min confidence >= 0.3
- **Minimum data**: At least 3 news items in the lookback window

### Technical Analysis
- **EMA Crossover**: Fast(9) crosses above/below Slow(21)
- **RSI Filter**: RSI(14) must NOT be overbought(>70) for longs or oversold(<30) for shorts
- **Volume Confirmation**: Current volume >= 1.5x the 20-period average volume
- **Data**: 5-minute candles, 50 candle lookback
- If volume data is unavailable, the volume filter is bypassed (not blocked)

### Signal Combining
- Both sentiment AND technical must agree (BULLISH+BULLISH or BEARISH+BEARISH)
- Confidence = 50% sentiment confidence + 50% technical confirmation
- For exits: trigger if EITHER sentiment OR technical flips against the position
- 5-minute re-entry cooldown after any exit (in SignalCombiner)

### Instrument Selection (Multi-Stock)
1. Match news headlines to stock keywords (direct match > sector match)
2. Calculate signal_strength = `sentiment_confidence x news_volume x (1 + direct_count x 0.5 + sector_count x 0.2)`
3. Check top 5 stocks by signal strength for technical confirmation
4. Verify margin affordability (margin < 90% of capital)
5. Pick the highest signal_strength candidate
6. Nifty index gets a 0.8x strength multiplier (prefer specific stock signals)

---

## 5. Risk Management Rules

### Position Sizing
- Default: 1 lot of the selected instrument
- Win streak scaling: After 2+ consecutive wins, scale to 2x position (anti-martingale)
- After any loss, reset to 1x
- Always verify margin affordability before entering

### Stop-Loss Calculation
- **Nifty index**: Fixed 30 points = Rs 750/trade (25 units x 30 pts)
- **Stock futures**: `SL_points = MAX_LOSS_PER_TRADE / quantity`, capped at 1% of entry price
- SL placed as SL-M (stop-loss market) order immediately after entry

### Trailing Stop
- **Index**: Activates after 10 points profit, trails by 20 points
- **Stocks**: Activates after 0.5% profit, trails by 0.4% of entry price
- Trail only moves in the profitable direction (never widens SL)
- Implemented by modifying the existing SL-M order's trigger price

### Daily Limits
| Limit | Value | Action |
|-------|-------|--------|
| Max daily loss | Rs 2,000 (2% of capital) | Halt all trading |
| Daily profit target | Rs 3,000 | Square-off and stop |
| Max trades/day | 6 | No new entries |
| Max consecutive losses | 2 | Halt trading |
| Loss cooldown | 300 seconds | Wait before re-entry |
| Max open positions | 2 | No new entries until a position closes |

---

## 6. Order Execution Patterns

### Zerodha Kite API
```python
# Entry: Market order
kite.place_order(
    variety=kite.VARIETY_REGULAR,
    exchange="NFO",
    tradingsymbol="NIFTY26APRFUT",
    transaction_type=kite.TRANSACTION_TYPE_BUY,
    quantity=25,
    product=kite.PRODUCT_MIS,
    order_type=kite.ORDER_TYPE_MARKET,
)

# Stop-Loss: SL-M order
kite.place_order(
    variety=kite.VARIETY_REGULAR,
    exchange="NFO",
    tradingsymbol="NIFTY26APRFUT",
    transaction_type=kite.TRANSACTION_TYPE_SELL,
    quantity=25,
    product=kite.PRODUCT_MIS,
    order_type=kite.ORDER_TYPE_SLM,
    trigger_price=24470.0,
)

# Modify trailing stop
kite.modify_order(
    variety=kite.VARIETY_REGULAR,
    order_id="order_id",
    trigger_price=24485.0,
)
```

### Retry Logic
- 3 attempts for entry, SL, and square-off orders
- 1-second delay between retries
- If all retries fail for SL, immediately square off the entry position

### Paper Trading Mode
- Same code path, but orders simulated using live LTP
- Entry fills at current LTP (no slippage simulation)
- SL triggers checked by comparing LTP to trigger_price on each iteration
- Square-off fills at current LTP
- Order IDs are `PAPER-{uuid}` format

### Critical Safety Rules
- NEVER place an entry without immediately placing a corresponding SL
- ALWAYS cancel pending SL orders BEFORE placing a square-off order
- ALWAYS wait for entry fill confirmation before placing SL
- In live mode, wait 2 seconds after order placement for fill

---

## 7. Brokerage and Charges (Zerodha Futures MIS)

| Charge | Rate |
|--------|------|
| Brokerage | Rs 20/order (flat), capped at 0.03% of turnover |
| STT | 0.02% on sell side only (MIS intraday) |
| Exchange txn | 0.0019% of total turnover |
| GST | 18% of (brokerage + exchange txn) |
| SEBI | Rs 10 per crore of turnover |
| Stamp duty | 0.002% on buy side |

### Breakeven Calculation
Use `estimate_breakeven_points()` from `trading/brokerage.py` to know how many points the price must move to cover charges. Typically ~2-3 points for Nifty.

---

## 8. Configuration Management

### Environment Variables (.env)
```
KITE_API_KEY=xxx
KITE_API_SECRET=xxx
PAPER_TRADE=true/false
ENABLE_STOCK_FUTURES=true/false
CAPITAL=100000
MAX_DAILY_LOSS=2000
DAILY_PROFIT_TARGET=3000
STOP_LOSS_POINTS=30
MAX_LOSS_PER_TRADE=1500
MAX_OPEN_POSITIONS=2
LOG_LEVEL=INFO
```

### Phased Rollout
| Phase | PAPER_TRADE | ENABLE_STOCK_FUTURES | Description |
|-------|------------|---------------------|-------------|
| 1 | true | false | Paper trade Nifty only |
| 1b | true | true | Paper trade Nifty + stocks |
| 2 | false | false | Live Nifty only |
| 3 | false | true | Live Nifty + 48 stocks |

### Settings Defaults
All settings in `config/settings.py` have sensible defaults. Environment variables override them. Use `int(os.getenv("KEY", "default"))` pattern.

---

## 9. Common Pitfalls and Rules

### DO
- Always paper trade new features for at least 1 week before going live
- Log every order, fill, SL modification, and exit with full details
- Calculate and display brokerage charges in P&L (gross vs net)
- Handle market holidays and weekends
- Implement graceful shutdown (SIGINT/SIGTERM → square off → report → exit)
- Use IST timezone consistently (Asia/Kolkata)
- Deduplicate news items (SHA256 hash of title + source)
- Rate-limit API calls (RSS feeds: 60s, Kite LTP: batch up to 500)

### DON'T
- Don't trade in the first 5 minutes after market open (09:15-09:20) — too volatile
- Don't enter new positions after 15:10 — not enough time to manage
- Don't widen stop-losses to "give more room" — this increases risk
- Don't remove the dual-signal requirement — it's the edge
- Don't trade without a stop-loss order in place
- Don't ignore brokerage — at Rs 40 round-trip, frequent small trades kill profitability
- Don't use `time.sleep()` in the main loop for anything other than the loop interval
- Don't mock the broker API in tests if you can use paper mode instead
- Don't hardcode lot sizes — they change when exchanges revise them
- Don't trust entry price from order placement — always verify fill price from order status

### Slippage Considerations
- Paper mode does NOT simulate slippage. Real trades will have ~1-2 point slippage on Nifty
- SL-M orders execute at market price AFTER trigger — may get worse than trigger price
- During high volatility, slippage can be 5-10+ points
- Factor slippage into breakeven calculations

---

## 10. Development Workflow

### Adding a New Indicator
1. Add calculation in `analysis/technical.py` (add field to `TechnicalResult`)
2. Mirror the calculation in `analysis/instrument_selector.py` → `_compute_technical()`
3. Use the indicator in signal logic (crossover detection, filtering)
4. Test with paper mode for at least 5 trading sessions

### Adding a New Data Source
1. Add RSS/API URL to `data/news_fetcher.py`
2. Add rate limit entry in `RATE_LIMITS` dict
3. Parse into `NewsItem` dataclass format
4. Deduplication handled automatically by `NewsDeduplicator`

### Adding a New Instrument
1. Add to `config/instruments.py` with symbol, lot_size, keywords, sector
2. Futures symbol resolution happens automatically via `get_stock_futures_symbol()`
3. Test with paper mode to verify candle fetching and order simulation

### Adding a New Risk Rule
1. Add the check in `trading/risk_manager.py` → `can_trade()` method
2. Return `(False, "reason")` when the rule triggers
3. Add any new state variables to `reset_daily_state()`
4. Log when the rule activates

### Debugging a Trade
1. Check `logs/trading_YYYY-MM-DD.log` for the full trade lifecycle
2. Look for: SIGNAL → ENTERED → trailing stop updates → Position closed
3. `log_trade()` writes structured JSON for each completed trade
4. Daily summary available via `strategy.get_daily_summary()`

### Key Dependencies
```
kiteconnect>=5.0.0      # Zerodha broker API
vaderSentiment>=3.3.2    # Sentiment analysis
feedparser>=6.0.10       # RSS feed parsing
pandas>=2.0.0            # OHLCV data manipulation
numpy>=1.24.0            # Numerical calculations
python-dotenv>=1.0.0     # .env file loading
Flask>=3.0.0             # OAuth callback server for Kite auth
```

---

## 11. Testing Checklist for Any Change

Before merging any trading logic change:
- [ ] All Python files compile: `python -m py_compile <file>`
- [ ] Config loads correctly: `python -c "from config import settings; print(settings.MAX_TRADES_PER_DAY)"`
- [ ] Paper mode runs without errors for at least 1 full iteration
- [ ] SL orders are placed for every entry
- [ ] Graceful shutdown squares off all positions
- [ ] Daily summary reports correct P&L
- [ ] Brokerage charges are deducted from gross P&L
- [ ] No hardcoded prices, lot sizes, or dates
- [ ] Log output includes all relevant trade details
