"""
Profit/loss calculator for each instrument.
Run this standalone to see realistic expectations:
    python profit_calculator.py
"""

from trading.brokerage import calculate_brokerage, estimate_breakeven_points

CAPITAL = 100_000
MIS_MARGIN_PCT = 0.10  # ~10% MIS margin

# Representative prices (approximate, will vary daily)
# symbol: (approx_price, lot_size)
INSTRUMENTS = {
    "NIFTY":      (22500, 25,   "index"),
    "RELIANCE":   (1300,  250,  "stock"),
    "TCS":        (3600,  175,  "stock"),
    "HDFCBANK":   (1600,  550,  "stock"),
    "INFY":       (1500,  400,  "stock"),
    "ICICIBANK":  (1100,  700,  "stock"),
    "ITC":        (430,   1600, "stock"),
    "SBIN":       (780,   750,  "stock"),
    "BHARTIARTL": (1700,  475,  "stock"),
    "KOTAKBANK":  (1800,  400,  "stock"),
    "LT":         (3400,  150,  "stock"),
    "AXISBANK":   (1100,  625,  "stock"),
    "MARUTI":     (12500, 100,  "stock"),
    "TATAMOTORS": (650,   1400, "stock"),
    "TITAN":      (3200,  175,  "stock"),
    "BAJFINANCE": (8500,  125,  "stock"),
    "WIPRO":      (250,   1500, "stock"),
    "TATASTEEL":  (140,   1100, "stock"),
    "M&M":        (2800,  350,  "stock"),
    "HINDUNILVR": (2300,  300,  "stock"),
    "SUNPHARMA":  (1800,  700,  "stock"),
    "ADANIENT":   (2400,  500,  "stock"),
    "NTPC":       (350,   2800, "stock"),
    "COALINDIA":  (380,   2100, "stock"),
}


def analyze_instrument(symbol, price, lot_size, inst_type):
    contract_value = price * lot_size
    margin_required = contract_value * MIS_MARGIN_PCT

    if margin_required > CAPITAL * 0.9:
        return None  # Can't afford

    # Brokerage for a round trip
    charges = calculate_brokerage(price, price, lot_size, "LONG", inst_type)
    brokerage = charges["total_charges"]
    breakeven_pts = estimate_breakeven_points(price, lot_size, inst_type)

    # Stop-loss: 30 pts for Nifty, 1% for stocks
    if inst_type == "index":
        sl_points = 30
    else:
        sl_points = round(price * 0.01, 1)

    sl_loss = sl_points * lot_size
    net_sl_loss = sl_loss + brokerage

    # Scenarios: 0.5%, 1%, 1.5%, 2% favorable move
    results = {}
    for pct in [0.5, 1.0, 1.5, 2.0, 3.0]:
        move_pts = price * pct / 100
        gross_profit = move_pts * lot_size
        net_profit = gross_profit - brokerage
        results[f"{pct}%_move"] = {
            "points": round(move_pts, 1),
            "gross": round(gross_profit, 0),
            "net": round(net_profit, 0),
        }

    return {
        "symbol": symbol,
        "price": price,
        "lot_size": lot_size,
        "contract_value": contract_value,
        "margin_required": round(margin_required, 0),
        "brokerage_round_trip": round(brokerage, 0),
        "breakeven_points": breakeven_pts,
        "breakeven_pct": round(breakeven_pts / price * 100, 3),
        "sl_points": sl_points,
        "sl_loss_gross": round(sl_loss, 0),
        "sl_loss_net": round(net_sl_loss, 0),
        "profit_scenarios": results,
    }


def main():
    print("=" * 90)
    print(f"  PROFIT/LOSS CALCULATOR | Capital: Rs {CAPITAL:,} | MIS Margin: {MIS_MARGIN_PCT*100:.0f}%")
    print("=" * 90)

    affordable = []
    for symbol, (price, lot_size, inst_type) in INSTRUMENTS.items():
        result = analyze_instrument(symbol, price, lot_size, inst_type)
        if result:
            affordable.append(result)

    # Sort by margin required
    affordable.sort(key=lambda x: x["margin_required"])

    print(f"\n{'Symbol':<12} {'Price':>8} {'Lot':>5} {'Contract':>10} {'Margin':>8} "
          f"{'Brkrg':>6} {'BE pts':>7} {'SL Loss':>8} "
          f"{'0.5%':>8} {'1.0%':>8} {'1.5%':>8} {'2.0%':>8}")
    print("-" * 120)

    for r in affordable:
        sc = r["profit_scenarios"]
        print(f"{r['symbol']:<12} {r['price']:>8,} {r['lot_size']:>5} "
              f"{r['contract_value']:>10,} {r['margin_required']:>8,.0f} "
              f"{r['brokerage_round_trip']:>6,.0f} {r['breakeven_points']:>7} "
              f"{r['sl_loss_net']:>8,.0f} "
              f"{sc['0.5%_move']['net']:>8,.0f} "
              f"{sc['1.0%_move']['net']:>8,.0f} "
              f"{sc['1.5%_move']['net']:>8,.0f} "
              f"{sc['2.0%_move']['net']:>8,.0f}")

    print("-" * 120)
    print("\nNOTE: Profit columns show NET profit (after brokerage+charges) for that % move")
    print("      SL Loss = stop-loss hit loss INCLUDING brokerage")
    print(f"      Instruments not shown = margin > Rs {CAPITAL*0.9:,.0f} (unaffordable)")

    # Best opportunities analysis
    print("\n" + "=" * 90)
    print("  BEST PROFIT POTENTIAL (sorted by net profit on 1% move)")
    print("=" * 90)

    by_profit = sorted(affordable, key=lambda x: x["profit_scenarios"]["1.0%_move"]["net"], reverse=True)
    print(f"\n{'Rank':<5} {'Symbol':<12} {'1% Net Profit':>14} {'SL Net Loss':>12} {'Risk:Reward':>12} {'Margin':>10}")
    print("-" * 70)

    for i, r in enumerate(by_profit[:15], 1):
        profit_1pct = r["profit_scenarios"]["1.0%_move"]["net"]
        sl_loss = r["sl_loss_net"]
        rr = abs(profit_1pct / sl_loss) if sl_loss != 0 else 0
        print(f"{i:<5} {r['symbol']:<12} Rs {profit_1pct:>10,.0f} Rs {sl_loss:>8,.0f} "
              f"{'1:'}{1/rr:.1f}" if rr > 0 else f"{i:<5} {r['symbol']:<12} Rs {profit_1pct:>10,.0f} Rs {sl_loss:>8,.0f} N/A",
              f"Rs {r['margin_required']:>7,.0f}")


if __name__ == "__main__":
    main()
