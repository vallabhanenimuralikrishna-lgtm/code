import os
import logging
from logging.handlers import TimedRotatingFileHandler
from config import settings


def setup_logging():
    log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
    os.makedirs(log_dir, exist_ok=True)

    log_format = "%(asctime)s [%(levelname)-8s] %(name)-20s %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, settings.LOG_LEVEL, logging.INFO))

    # Console handler
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    try:
        import colorlog
        console.setFormatter(colorlog.ColoredFormatter(
            "%(log_color)s%(asctime)s [%(levelname)-8s]%(reset)s %(name)-20s %(message)s",
            datefmt=date_format,
            log_colors={
                "DEBUG": "cyan",
                "INFO": "green",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "bold_red",
            },
        ))
    except ImportError:
        console.setFormatter(logging.Formatter(log_format, datefmt=date_format))
    root_logger.addHandler(console)

    # File handler (daily rotation, 30 days)
    file_handler = TimedRotatingFileHandler(
        os.path.join(log_dir, "bot.log"),
        when="midnight",
        interval=1,
        backupCount=30,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(log_format, datefmt=date_format))
    root_logger.addHandler(file_handler)

    # Trade-specific CSV logger
    trade_logger = logging.getLogger("trades")
    trade_handler = TimedRotatingFileHandler(
        os.path.join(log_dir, "trades.csv"),
        when="midnight",
        interval=1,
        backupCount=90,
        encoding="utf-8",
    )
    trade_handler.setLevel(logging.INFO)
    trade_handler.setFormatter(logging.Formatter("%(message)s"))
    trade_logger.addHandler(trade_handler)
    trade_logger.propagate = False

    return root_logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def log_trade(direction, entry_price, exit_price, qty, pnl, entry_signal, exit_reason, duration_sec):
    trade_logger = logging.getLogger("trades")
    trade_logger.info(
        f"{direction},{entry_price},{exit_price},{qty},{pnl:.2f},"
        f"{entry_signal},{exit_reason},{duration_sec}"
    )
