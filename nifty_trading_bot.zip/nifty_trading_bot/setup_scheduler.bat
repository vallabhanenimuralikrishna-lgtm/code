@echo off
:: ============================================
:: Sets up Windows Task Scheduler to run the
:: trading bot at 9:00 AM on weekdays (Mon-Fri)
:: Run this ONCE as Administrator
:: ============================================

echo ============================================
echo   Setting up Daily Trading Bot Schedule
echo ============================================
echo.

:: Check for admin rights
net session >nul 2>&1
if errorlevel 1 (
    echo ERROR: Run this as Administrator!
    echo Right-click setup_scheduler.bat and select "Run as administrator"
    pause
    exit /b 1
)

set BOT_DIR=%~dp0
set TASK_NAME=NiftyTradingBot

:: Delete existing task if any
schtasks /delete /tn "%TASK_NAME%" /f >nul 2>&1

:: Create scheduled task: 9:00 AM, Monday-Friday
schtasks /create ^
    /tn "%TASK_NAME%" ^
    /tr "\"%BOT_DIR%run.bat\"" ^
    /sc weekly ^
    /d MON,TUE,WED,THU,FRI ^
    /st 09:00 ^
    /rl HIGHEST ^
    /f

if errorlevel 1 (
    echo.
    echo ERROR: Failed to create scheduled task.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   SUCCESS! Task scheduled.
echo ============================================
echo.
echo   Task name: %TASK_NAME%
echo   Schedule:  9:00 AM, Monday to Friday
echo   Action:    Runs %BOT_DIR%run.bat
echo.
echo   The bot will:
echo     - Start at 9:00 AM (before market opens at 9:15)
echo     - Open browser for Zerodha login
echo     - Trade from 9:20 AM to 3:15 PM
echo     - Auto square-off and exit by 3:30 PM
echo.
echo   To verify: Open Task Scheduler and look for "%TASK_NAME%"
echo   To remove: Run "schtasks /delete /tn %TASK_NAME% /f"
echo.
pause
